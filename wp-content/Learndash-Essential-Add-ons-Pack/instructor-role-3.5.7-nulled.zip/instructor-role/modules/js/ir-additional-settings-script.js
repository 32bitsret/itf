jQuery(function(){
    jQuery('.ir-accordion').accordion({
        collapsible: true
    });
});