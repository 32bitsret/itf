import '../scss/ir-style.scss';
import irProfile from './dev';

var irprofile = new irProfile;

irprofile.irTabs();
irprofile.addReadMore();
