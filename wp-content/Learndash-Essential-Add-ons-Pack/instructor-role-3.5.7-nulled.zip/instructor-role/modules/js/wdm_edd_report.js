jQuery( document ).ready(
	function(){
		jQuery( "#edd-dashboard-widgets-wrap:has(#edd-graphs-filter)" ).hide();
	}
);
