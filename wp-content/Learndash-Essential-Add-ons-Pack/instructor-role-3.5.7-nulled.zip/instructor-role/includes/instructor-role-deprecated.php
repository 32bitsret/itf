<?php
/**
 * Deprecated functions
 *
 * @since      3.5.0
 * @package    Instructor_Role
 * @subpackage Instructor_Role/includes
 * @author     WisdmLabs <support@wisdmlabs.com>
 */

// namespace InstructorRole\Includes;
