<?php
defined( 'ABSPATH' ) or die( "No script kiddies please!" );

do_action('ir_admin_customizer_start');
include('common/header.php');
include('plugin-settings.php');
include('common/footer.php');