<?php defined( 'ABSPATH' ) or die( "No script kiddies please!" ); ?>
<div class='ir-admin-customizer-title'>
    <?php _e('Admin Customizer', 'wdm_instructor_role'); ?>
</div>

<div id="<?php echo E_ADMIN_PLUGIN_PREFIX; ?>-admin-main-wrapper" class="<?php echo E_ADMIN_PLUGIN_PREFIX; ?>-admin-main-wrapper">
	<!-- <div class="<?php // echo E_ADMIN_PLUGIN_PREFIX; ?>-header-wrapper clearfix">
    </div> -->