import '../scss/common.scss';

import prepareZipFile from './prepare-zip';

window.prepareZipFile = prepareZipFile;
