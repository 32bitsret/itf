<?php
// Silence is gloden
