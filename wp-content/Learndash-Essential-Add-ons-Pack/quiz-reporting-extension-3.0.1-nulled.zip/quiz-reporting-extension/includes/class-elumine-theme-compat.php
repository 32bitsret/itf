<?php
/**
 * Elumine theme integration and compatibility.
 *
 * @package Quiz Reporting Extension
 * @since   3.0.0
 */

defined( 'ABSPATH' ) || exit;
if ( ! class_exists( 'Elumine_Theme_Compat' ) ) {
	/**
	 * Elumine_Theme_Compat Class.
	 *
	 * @class Elumine_Theme_Compat
	 */
	class Elumine_Theme_Compat {
		/**
		 * The single instance of the class.
		 *
		 * @var Elumine_Theme_Compat
		 * @since 2.1
		 */
		protected static $instance = null;

		/**
		 * Elumine_Theme_Compat Instance.
		 *
		 * Ensures only one instance of Elumine_Theme_Compat is loaded or can be loaded.
		 *
		 * @since 3.0.0
		 * @static
		 * @return Elumine_Theme_Compat - instance.
		 */
		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Elumine_Theme_Compat Constructor.
		 */
		public function __construct() {
			$this->init_hooks();
		}

		/**
		 * Hook into actions and filters.
		 *
		 * @since 3.0.0
		 */
		private function init_hooks() {
			add_filter( 'qre_reports_header_logo', array( $this, 'load_elumine_custom_header' ), 10, 1 );
			add_action( 'wp_enqueue_scripts', array( $this, 'elumine_toggle_compatibility_patch' ) );
		}

		/**
		 * Load Dark Header for eLumine theme.
		 *
		 * @param  integer $header Attachment ID for the header.
		 * @return integer Attachment ID for the header.
		 */
		public function load_elumine_custom_header( $header ) {
			// $theme = wp_get_theme(); // gets the current theme.
			if ( 'elumine' === get_option( 'template' ) ) {
				return function_exists( 'fw_get_db_settings_option' ) ? fw_get_db_settings_option( 'site-logo-dark' )['attachment_id'] : $header;
			}
			return $header;
		}

		/**
		 * The eLumine theme JS breaks the structure for input radios and checkbox.
		 * Need to add a fix for date toggle used in QRE Dashboard.
		 */
		public function elumine_toggle_compatibility_patch() {
			// $theme = wp_get_theme(); // gets the current theme.
			if ( 'elumine' === get_option( 'template' ) ) {
				wp_register_script( 'toggle-box-js', '', array(), time(), true );
				wp_enqueue_script( 'toggle-box-js' );
				wp_add_inline_script(
					'toggle-box-js',
					'jQuery(window).on("load",function(){
			            setTimeout(
			                function(){
			                    if (jQuery(".qre-reports-content label.switch").find(".wdm-checkbox").length > 0){
			                        var togglewrap = jQuery(".qre-reports-content label.switch");
			                        var toggle = togglewrap.find("input[type=checkbox]").detach();
			                        togglewrap.prepend(toggle);
			                        togglewrap.find(".wdm-checkbox").remove();
			                    }
			                },
			            500);
			        });'
				);
			}
		}
	}
}
