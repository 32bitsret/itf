<?php
/**
 * QRE setup
 *
 * @package Quiz Reporting Extension
 * @since   3.0.0
 */

defined( 'ABSPATH' ) || exit;
if ( ! class_exists( 'Quiz_Reporting_Autoloader' ) ) {
	/**
	 * Main Quiz_Reporting_Autoloader Class.
	 *
	 * @class Quiz_Reporting_Autoloader
	 */
	class Quiz_Reporting_Autoloader {

		/**
		 * The single instance of the class.
		 *
		 * @var Quiz_Reporting_Autoloader
		 * @since 2.1
		 */
		protected static $instance = null;

		/**
		 * The paths in which to look for class.
		 *
		 * @var array Array of paths.
		 */
		protected $paths = array(
			'admin/',
			'includes/',
			'includes/question-types/',
			'public/',
			'includes/shortcodes/',
			'includes/shortcodes/statistic-details/',
		);

		/**
		 * QRE Autoloader Instance.
		 *   *
		 *
		 * @since 3.0.0
		 * @static
		 * @return QRE Autoloader Instance.
		 */
		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Quiz_Reporting_Autoloader Constructor.
		 */
		public function __construct() {
		}

		/**
		 * Used to initiate spl_autload_register.
		 *
		 * @return void.
		 */
		public function autoload_init() {
			spl_autoload_register( array( $this, 'autoload' ) );
		}

		/**
		 * Autoload function to calculate the file name and include it based on WPCS.
		 *
		 * @param  string $class_name Class Name.
		 * @return void.
		 */
		public function autoload( $class_name ) {
			// Remove Namespaces from the classname.
			$class_with_namespace = explode( '\\', $class_name );
			$class                = end( $class_with_namespace );
			// Change from camelcaps to hyphen separated for fetching filenames.
			$pieces = explode( '_', $class );
			$class  = strtolower( implode( '-', $pieces ) );

			foreach ( $this->paths as $path ) {
				if ( file_exists( QRE_PLUGIN_DIR . $path . 'class-' . $class . '.php' ) ) {
					include_once QRE_PLUGIN_DIR . $path . 'class-' . $class . '.php';
					break;
				}
			}
		}
	}
}
