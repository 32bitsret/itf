<?php
/**
 * QRE setup
 *
 * @package Quiz Reporting Extension
 * @since   3.0.0
 */

defined( 'ABSPATH' ) || exit;
if ( ! class_exists( 'Quiz_Reporting_Extension' ) ) {
	/**
	 * Main Quiz_Reporting_Extension Class.
	 *
	 * @class Quiz_Reporting_Extension
	 */
	final class Quiz_Reporting_Extension {

		/**
		 * QRE version.
		 *
		 * @var string
		 */
		public $version = '3.0.1';

		/**
		 * The single instance of the class.
		 *
		 * @var Quiz_Reporting_Extension
		 * @since 2.1
		 */
		protected static $instance = null;

		/**
		 * The instances of all the included classes.
		 *
		 * @var Array of instances
		 * @since 3.0.0
		 */
		protected $instances = array();

		/**
		 * Main QRE Instance.
		 *
		 * Ensures only one instance of Quiz Reporting Extension is loaded or can be loaded.
		 *
		 * @since 3.0.0
		 * @static
		 * @see QRE()
		 * @return QRE - Main instance.
		 */
		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Returns a list of all class instances used by this class.
		 *
		 * @return array Array of dependent class instances.
		 */
		public function instances() {
			return $this->instances;
		}

		/**
		 * Quiz_Reporting_Extension Constructor.
		 */
		public function __construct() {
			/**
			 * Detect plugin. For use on Front End only.
			 */
			include_once ABSPATH . 'wp-admin/includes/plugin.php';

			if ( ! is_plugin_active( 'sfwd-lms/sfwd_lms.php' ) ) {
				return;
			}
			$this->define_constants();
			$this->autoload_classes();
			$this->includes();
			$this->set_instances();
			$this->init_processes();
			$this->init_hooks();
		}

		/**
		 * Define QRE Constants.
		 */
		private function define_constants() {
			$this->define( 'QRE_PLUGIN_DIR', dirname( QRE_PLUGIN_FILE ) . '/' );
			$this->define( 'QRE_PLUGIN_BASENAME', plugin_basename( QRE_PLUGIN_FILE ) );
			$this->define( 'QRE_PLUGIN_VERSION', $this->version );
			$this->define( 'MPDF_ALL_FONTS_URL', 'https://wisdmlabs.com/all-fonts/' );
			$this->define( 'QRE_PLUGIN_URL', plugin_dir_url( QRE_PLUGIN_FILE ) );
		}

		/**
		 * Define constant if not already set.
		 *
		 * @param string      $name  Constant name.
		 * @param string|bool $value Constant value.
		 */
		private function define( $name, $value ) {
			if ( ! defined( $name ) ) {
				define( $name, $value );
			}
		}

		/**
		 * Class Autoloader initialization
		 */
		public function autoload_classes() {
			/**
			 * Class Autoloader.
			 */
			include_once QRE_PLUGIN_DIR . 'includes/class-quiz-reporting-autoloader.php';

			$autoloader = Quiz_Reporting_Autoloader::instance();
			$autoloader->autoload_init();
		}

		/**
		 * Include required core files used in admin and on the frontend.
		 */
		public function includes() {

			/**
			 * Pluggable functions
			 */
			include_once QRE_PLUGIN_DIR . 'includes/functions.php';

			/**
			 * Load Composer Packages.
			 */
			include_once QRE_PLUGIN_DIR . 'vendor/autoload.php';

			/**
			 * ====================================================================
			 *
			 * Load Other Packages below.
			 *
			 * ====================================================================
			 */
		}

		/**
		 * This method is used to store instances of dependencies.
		 */
		private function set_instances() {
			$this->instances['export-db']            = Quiz_Export_Db::instance();
			$this->instances['link-generator']       = Qre_Link_Generator::instance();
			$this->instances['instructor-dashboard'] = Instructor_Dashboard_Link::instance();
			$this->instances['export-data']          = Quiz_Export_Data::instance();
			$this->instances['frontend']             = Quiz_Reporting_Frontend::instance();
			$this->instances['statistics_details']   = new Quiz_Reporting_Shortcode_Statistic_Details();
			$this->instances['page-template']        = Qre_Page_Templates::instance();
			$this->instances['elumine-compat']       = Elumine_Theme_Compat::instance();
		}

		/**
		 * This method is used to get instance of a particular class or all instances related to baseclass.
		 *
		 * @param string $instance_of Class Slug/Array Key.
		 * @return Array/Object
		 */
		public function get_instances( $instance_of = '' ) {
			switch ( $instance_of ) {
				case 'export-db':
					return $this->instances['export-db'];
					break;
				case 'link-generator':
					return $this->instances['link-generator'];
					break;
				case 'export-data':
					return $this->instances['export-data'];
					break;
				case 'frontend':
					return $this->instances['frontend'];
					break;
				case 'statistics_details':
					return $this->instances['statistics_details'];
					break;
				case 'page-template':
					return $this->instances['page-template'];
					break;
				case 'elumine-compat':
					return $this->instances['elumine-compat'];
					break;
				default:
					return $this->instances;
					break;
			}
		}

		/**
		 * Any init level processing the plugin requires.
		 * This can include first time install processes, data upgrade processes on plugin updates etc.
		 */
		private function init_processes() {
			// Set Plugin version in the database on first install.
			if ( false !== get_option( 'qre_plugin_version', false ) ) {
				update_option( 'qre_plugin_version', $this->version );
			}
			// Set Plugin version in the database on plugin update.
			if ( get_option( 'qre_plugin_version', false ) !== $this->version ) {
				update_option( 'qre_plugin_version', $this->version );
			}
		}

		/**
		 * Hook into actions and filters.
		 *
		 * @since 3.0.0
		 */
		private function init_hooks() {
			add_action( 'plugins_loaded', array( $this, 'load_license' ), 9 );
			add_action( 'plugins_loaded', array( $this, 'show_notices' ) );
			add_action( 'init', array( $this, 'load_textdomain' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'load_common_assets' ) );
			add_action( 'wp_enqueue_scripts', array( $this, 'load_common_assets' ) );
			add_action( 'wp_enqueue_scripts', array( $this, 'register_frontend_assets' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'register_admin_assets' ) );
		}

		/**
		 * This function is used to load the licensing logic to get plugin updates.
		 */
		public function load_license() {
			global $qre_plugin_data;
			$qre_plugin_data = include_once QRE_PLUGIN_DIR . 'license.config.php';
			require_once QRE_PLUGIN_DIR . 'licensing/class-wdm-license.php';
			new Licensing\WdmLicense( $qre_plugin_data );
		}

		/**
		 * Check if LearnDash is active, trigger admin notice and deactivate the plugin.
		 */
		public function show_notices() {
			// check if learndash is active.
			include_once ABSPATH . 'wp-admin/includes/plugin.php';

			// check dependency activation.
			if ( ! is_plugin_active( 'sfwd-lms/sfwd_lms.php' ) ) {
				// deactivate_plugins( QRE_PLUGIN_BASENAME );.
				unset( $_GET['activate'] );// phpcs:ignore WordPress.Security.NonceVerification
				add_action( 'admin_notices', array( $this, 'admin_notices' ) );
			}
		}

		/**
		 * To show admin notice if LearnDash LMS is deactivated.
		 *
		 * @since 3.0.0
		 */
		public function admin_notices() {
			$err_inst_msg = sprintf(
				/* translators: 1: LearnDash 2: Quiz Reporting Extension 3: LearnDash */
				__( '%1$s plugin is not active. In order to make %2$s plugin work, you need to install and activate %3$s first.', 'quiz_reporting_learndash' ),
				'<b>' . __( 'LearnDash LMS', 'quiz_reporting_learndash' ) . '</b>',
				'<b>' . __( 'Quiz Reporting Plugin', 'quiz_reporting_learndash' ) . '</b>',
				'<b>' . __( 'LearnDash LMS', 'quiz_reporting_learndash' ) . '</b>'
			);
			echo '<div class="error"><p>' . $err_inst_msg . '</p></div>';// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		/**
		 * Load the plugin text domain
		 */
		public function load_textdomain() {
			load_plugin_textdomain( 'quiz_reporting_learndash', false, QRE_PLUGIN_DIR . 'languages' );
		}

		/**
		 * This method is used to load common assets.
		 *
		 * @return void
		 */
		public function load_common_assets() {
			wp_register_script( 'page_blocker', QRE_PLUGIN_URL . 'assets/dist/js/page_blocker.min.js', array( 'jquery' ), $this->get_file_version( '/assets/dist/js/page_blocker.min.js' ), false );
			if ( is_rtl() ) {
				wp_enqueue_style( 'qre-common-css', QRE_PLUGIN_URL . 'assets/dist/css/common-rtl.css', array(), $this->get_file_version( '/assets/dist/css/common-rtl.css' ) );
			} else {
				wp_enqueue_style( 'qre-common-css', QRE_PLUGIN_URL . 'assets/dist/css/common.css', array(), $this->get_file_version( '/assets/dist/css/common.css' ) );
			}
			wp_enqueue_script( 'qre-common-js', QRE_PLUGIN_URL . 'assets/dist/js/common.js', array( 'jquery' ), $this->get_file_version( '/assets/dist/js/common.js' ), false );
		}

		/**
		 * This method is used to register frontend scripts.
		 *
		 * @return void
		 */
		public function register_frontend_assets() {
			if ( is_rtl() ) {
				wp_register_style( 'qre_public_css', QRE_PLUGIN_URL . 'assets/dist/css/public-rtl.css', array(), $this->get_file_version( '/assets/dist/css/public-rtl.css' ) );
			} else {
				wp_register_style( 'qre_public_css', QRE_PLUGIN_URL . 'assets/dist/css/public.css', array(), $this->get_file_version( '/assets/dist/css/public.css' ) );
			}
			wp_register_script( 'qre_export_frontend', QRE_PLUGIN_URL . 'assets/dist/js/public.js', array( 'jquery' ), $this->get_file_version( '/assets/dist/js/public.js' ), false );
		}

		/**
		 * This method is used to register admin assets.
		 *
		 * @return void
		 */
		public function register_admin_assets() {
			if ( is_rtl() ) {
				wp_register_style( 'qre_admin_css', QRE_PLUGIN_URL . 'assets/dist/css/admin-rtl.css', array(), $this->get_file_version( '/assets/dist/css/admin-rtl.css' ) );
			} else {
				wp_register_style( 'qre_admin_css', QRE_PLUGIN_URL . 'assets/dist/css/admin.css', array(), $this->get_file_version( '/assets/dist/css/admin.css' ) );
			}
			wp_register_script( 'qre_export_js', QRE_PLUGIN_URL . 'assets/dist/js/admin.js', array( 'jquery' ), $this->get_file_version( '/assets/dist/js/admin.js' ), false );
		}

		/**
		 * Get the plugin path.
		 *
		 * @return string
		 */
		public function plugin_path() {
			return untrailingslashit( QRE_PLUGIN_DIR );
		}

		/**
		 * Get the template path.
		 *
		 * @return string
		 */
		public function template_path() {
			/**
			 *
			 * Relative Path for template directory.
			 *
			 * Path to look inside the theme to find plugin templates are loaded.
			 *
			 * @since 3.0.0
			 * @see get_template
			 *
			 * @param type $path Relative Path.
			 */
			return apply_filters( 'qre_template_path', 'quiz-reporting-extension/' );
		}

		/**
		 * Return Template filepath.
		 *
		 * @param string $template template to load.
		 * @return string path of the template file.
		 */
		public static function get_template( $template ) {

			$check_dirs = array(
				trailingslashit( get_stylesheet_directory() ) . QRE()->template_path(),
				trailingslashit( get_template_directory() ) . QRE()->template_path(),
				trailingslashit( get_stylesheet_directory() ),
				trailingslashit( get_template_directory() ),
				trailingslashit( QRE()->plugin_path() ) . 'templates/',
			);

			foreach ( $check_dirs as $dir ) {
				if ( file_exists( trailingslashit( $dir ) . $template ) ) {
					return trailingslashit( $dir ) . $template;
				}
			}
		}

		/**
		 * Get the file modified time as a cache buster if we're in dev mode.
		 *
		 * @param string $file Local path to the file.
		 * @return string The cache buster value to use for the given file.
		 */
		protected function get_file_version( $file ) {
			if ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG && file_exists( $this->plugin_path() . $file ) ) {
				return filemtime( $this->plugin_path() . $file );
			}
			return QRE_PLUGIN_VERSION;
		}
	}
}
