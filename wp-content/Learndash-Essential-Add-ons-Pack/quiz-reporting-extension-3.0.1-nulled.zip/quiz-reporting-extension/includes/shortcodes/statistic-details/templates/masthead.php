<?php
/**
 * Template is used to show site identity and menus in the header.
 *
 * @package Quiz Reporting Extension
 * @since 3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$header         = array(
	'logo_alt' => '',
	'logo_url' => '',
	'text'     => '',
	'text_url' => '',
);
$header['logo'] = apply_filters( 'qre_reports_header_logo', get_custom_logo() );
$site_title     = get_bloginfo( 'name' );
if ( has_custom_logo() ) {
	$header['logo_alt'] = get_post_meta( $header['logo'], '_wp_attachment_image_alt', true );
	/**
	 * Filters header logo alternative text.
	 * This filter will be called only if there is a logo set in WordPress Customizer' Site Logo settings.
	 *
	 * @param string $logo_alt  Header logo alternative text.
	 */
	$header['logo_alt'] = apply_filters( 'qre_reports_header_logo_alt', $header['logo_alt'] );
	/**
	 * Filters Focus mode header logo URL.
	 * This filter will be called only if there is a logo set in LearnDash plugin settings.
	 *
	 * @param string $logo_url  Header logo URL.
	 * @param string            Home URL.
	 */
	$header['logo_url'] = apply_filters( 'qre_reports_header_logo_url', get_home_url() );
} else {
	/**
	 * Filters header text. This text is used to display in place of the logo.
	 * This filter will be called only if there is a site title set.
	 *
	 * @param string $site_title  Site Title.
	 */
	$header['text'] = apply_filters( 'qre_reports_header_text', $site_title );
	if ( ! empty( $header['text'] ) ) {
		/**
		 * Filters header text URL.
		 * This filter will be called only if there is no logo set in LearnDash plugin settings.
		 *
		 * @param string $header_text_url Header Text URL
		 */
		$header['text_url'] = apply_filters( 'qre_reports_header_text_url', get_home_url() );
	}
}
?>
<div class="qre-reports-header">

	<?php
	/**
	 * Fires before the header logo in the focus template.
	 */
	do_action( 'qre_reports_header_before_logo' );
	?>

	<div class="qre-brand-logo">
		<?php
		$site_branding = '';
		if ( ! empty( $header['logo'] ) ) {
			if ( ! empty( $header['logo_url'] ) ) {
				$site_branding .= '<a href="' . esc_url( $header['logo_url'] ) . '">';
			}
			$site_branding .= '<img src="' . esc_url( wp_get_attachment_url( $header['logo'] ) ) . '" alt="' . esc_html( $header['logo_alt'] ) . '" />';
			if ( ! empty( $header['logo_url'] ) ) {
				$site_branding .= '</a>';
			}
		} else {
			if ( ! empty( $header['text'] ) ) {
				if ( ! empty( $header['text_url'] ) ) {
					$site_branding .= '<a href="' . esc_url( $header['text_url'] ) . '">';
				}
				$site_branding .= esc_html( $header['text'] );
				if ( ! empty( $header['text_url'] ) ) {
					$site_branding .= '</a>';
				}
			}
		}

		/**
		 * Filters QRE Reports site branding markup.
		 *
		 * @param string $site_branding Focus mode header element markup.
		 * @param array  $header         Array of header element details keyed logo_alt, logo_url, text, text_url.
		 */
		$site_branding = apply_filters( 'qre_reports_site_branding', $site_branding, $header );
		echo $site_branding; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Outputs HTML for the header element
		?>
	</div>

	<?php
	/**
	 * Fires after the header logo in the template.
	 */
	do_action( 'qre_reports_header_after_logo' );

	/**
	 * Toggles showing primary menu links on reports page.
	 *
	 * @param boolean $show whether to show primary menu items on profile dropdown
	 */
	if ( has_nav_menu( 'primary' ) && apply_filters( 'qre_show_primary_menu_items', true ) ) {
		?>
		<div class="primary-desktop-navigation">
			<div class="qre-nav-container">
				<nav id="site-navigation" class="main-navigation navbar-nav" role="navigation" aria-label="<?php esc_attr_e( 'Primary Menu', 'quiz_reporting_learndash' ); ?>">
					<?php
					wp_nav_menu(
						array(
							'container'      => 'div',
							'menu_class'     => 'primary-menu',
							'theme_location' => 'primary',
						)
					);
					?>
				</nav>
			</div>
		</div>
		<?php
	}
	?>
	<?php if ( is_user_logged_in() ) : ?>
		<div class="qre-user-menu">
			<?php
			$user_id = get_current_user_id();
			/**
			 * Fires before the user menu in the template.
			 *
			 * @param int $user_id   User ID.
			 */
			do_action( 'qre_reports_header_user_menu_before', $user_id );

			$user_data = get_userdata( $user_id );
			?>

			<span class="qre-reports-profile-avatar">
				<?php
				/**
				 * Fires before the user avatar in the template.
				 *
				 * @param int $user_id   User ID.
				 */
				do_action( 'qre_reports_header_avatar_before', $user_id );
				echo get_avatar( $user_id );
				/**
				 * Fires after the user avatar in the focus template.
				 *
				 * @param int $user_id   User ID.
				 */
				do_action( 'qre_reports_header_avatar_after', $user_id );
				?>
			</span> <!--/.qre-reports-profile-avatar-->

			<?php
			/**
			 * Fires before the header user dropdown in the focus template.
			 *
			 * @param int $user_id   User ID.
			 */
			do_action( 'qre_reports_header_user_dropdown_before', $user_id );
			?>

			<span class="qre-user-menu-items">
				<?php
				/**
				 * Toggles showing ld30 focus mode menu links on reports page.
				 *
				 * @param boolean $show whether to show ld30 focus mode menu items on profile dropdown.
				 */
				if ( has_nav_menu( 'ld30_focus_mode' ) && apply_filters( 'qre_show_ld30_focus_menu_items', true ) ) {
					$locations           = get_nav_menu_locations();
					$secondary_menu_slug = $locations['ld30_focus_mode'];
					$custom_menu_items   = wp_get_nav_menu_items( $secondary_menu_slug );
				}
				/**
				 * Toggles showing secondary menu links on reports page.
				 *
				 * @param boolean $show whether to show secondary menu items on profile dropdown.
				 */
				if ( has_nav_menu( 'secondary' ) && apply_filters( 'qre_show_secondary_menu_items', true ) ) {
					$locations           = get_nav_menu_locations();
					$secondary_menu_slug = $locations['secondary'];
					$custom_menu_items   = wp_get_nav_menu_items( $secondary_menu_slug );
				}

				$menu_items = array();
				if ( $custom_menu_items ) :
					foreach ( $custom_menu_items as $menu_item ) :
						$menu_items[ $menu_item->post_name ] = array(
							'url'        => $menu_item->url,
							'label'      => $menu_item->title,
							'classes'    => esc_attr( 'qre-reports-menu-link qre-reports-menu-' . $menu_item->post_name ),
							'target'     => '',
							'attr_title' => '',
							'xfn'        => '',
						);

						if ( ( property_exists( $menu_item, 'classes' ) ) && ( is_array( $menu_item->classes ) ) ) {
							$classes = array_filter( $menu_item->classes, 'strlen' );
							if ( ! empty( $classes ) ) {
								$menu_items[ $menu_item->post_name ]['classes'] .= ' ' . implode( ' ', $classes );
							}
						}

						if ( ( property_exists( $menu_item, 'target' ) ) && ( ! empty( $menu_item->target ) ) ) {
							$menu_items[ $menu_item->post_name ]['target'] = esc_attr( $menu_item->target );
						}

						if ( ( property_exists( $menu_item, 'attr_title' ) ) && ( ! empty( $menu_item->attr_title ) ) ) {
							$menu_items[ $menu_item->post_name ]['attr_title'] = esc_attr( $menu_item->attr_title );
						}
						if ( ( property_exists( $menu_item, 'xfn' ) ) && ( ! empty( $menu_item->xfn ) ) ) {
							$menu_items[ $menu_item->post_name ]['xfn'] = esc_attr( $menu_item->xfn );
						}

					endforeach;
				endif;

				if ( ! in_array( 'logout', $menu_items, true ) ) {
					$menu_items['logout'] = array(
						'url'   => wp_logout_url(),
						'label' => __( 'Logout', 'quiz_reporting_learndash' ),
					);
				}


				/**
				 * Reporting Dashboard Header menu items.
				 *
				 * @since 3.2.3
				 *
				 * @param  array $menu_items Array of menu items.
				 * @param  int   $user_id    Current User ID.
				 * @return array Menu Items.
				 */
				$menu_items = apply_filters( 'qre_reports_header_user_dropdown_items', $menu_items, $user_id );

				if ( $menu_items && ! empty( $menu_items ) ) :
					foreach ( $menu_items as $slug => $item ) :
						?>
						<a <?php if ( ! empty( $item['classes'] ) ) { ?>
							class="<?php echo esc_attr( $item['classes'] ); ?>"
						<?php } ?> <?php if ( ! empty( $item['target'] ) ) { ?>
							target="<?php echo esc_attr( $item['target'] ); ?>"
						<?php } ?> <?php if ( ! empty( $item['xfn'] ) ) { ?>
							rel="<?php echo esc_attr( $item['xfn'] ); ?>"
						<?php } ?> <?php if ( ! empty( $item['attr_title'] ) ) { ?>
							title="<?php echo esc_attr( $item['attr_title'] ); ?>"
						<?php } ?> href="<?php echo esc_url( $item['url'] ); ?>"><?php echo apply_filters( 'the_title', $item['label'], 0 );// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
						<?php
					endforeach;
				endif;
				?>
			</span> <!--/.qre-user-menu-items-->

			<?php
			/**
			 * Fires before the header user dropdown in the focus template.
			 *
			 * @param int $user_id   User ID.
			 */
			do_action( 'qre_reports_header_user_dropdown_after', $user_id );
			?>

		</div>
	<?php else : ?>
		<div class="qre-user-menu">
			<a href="<?php echo esc_url( wp_login_url( get_permalink() ) ); ?>"><?php esc_html_e( 'Login', 'quiz_reporting_learndash' ); ?></a>
		</div>
	<?php endif; ?>
</div> <!--/.qre-reports-header-->
