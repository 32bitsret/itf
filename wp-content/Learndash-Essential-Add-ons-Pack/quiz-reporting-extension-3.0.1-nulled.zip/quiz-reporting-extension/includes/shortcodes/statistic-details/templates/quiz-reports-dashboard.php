<?php
/**
 * Template Name: Quiz Reporting Dashboard
 * Description: A Page Template for Quiz Reports Dashboard.
 *
 * @package Quiz Reporting Extension
 */

QRE()->get_instances( 'page-template' )->add_body_class( 'qre-template-full-width' );
$report_type = filter_input( INPUT_GET, 'report', FILTER_SANITIZE_STRING );
if ( empty( $report_type ) || ! in_array( $report_type, array( 'quiz', 'custom' ), true ) ) {
	$report_type = 'quiz';
}
$screen_type = filter_input( INPUT_GET, 'screen', FILTER_SANITIZE_STRING );
if ( empty( $screen_type ) || ! in_array( $screen_type, array( 'user', 'quiz' ), true ) ) {
	$screen_type = 'listing';
}
QRE()->get_instances( 'page-template' )->add_body_class( $report_type . '-qre-report' );
if ( 'quiz' === $report_type && 'listing' === $screen_type ) {                  // Dashboard Home Page.
	QRE()->get_instances( 'page-template' )->add_body_class( 'grey-header' );
} elseif ( 'quiz' === $report_type && 'listing' !== $screen_type ) {            // User and Quiz dashboard Pages.
	QRE()->get_instances( 'page-template' )->add_body_class( 'no-sidebar' );
}

if ( 'quiz' === $report_type ) {
	QRE()->get_instances( 'page-template' )->add_body_class( 'grey-header' );
}

include 'header.php';

/**
 * Before Quiz Reporting Dashboard page template content.
 *
 * Fires before the content of Quiz Reporting Dashboard page template.
 */
do_action( 'qre_dashboard_before_content' );
if ( have_posts() ) :
		// Start the loop.
	while ( have_posts() ) :
		the_post();
		/**
		 * Fires before the sidebar in the current template.
		 */
		do_action( 'qre_reports_before_sidebar' );

		include 'sidebar.php';
		?>
		<div class="qre-reports-main">
			<?php
			/**
			 * Fires before the masthead in the current template.
			 */
			do_action( 'qre_reports_before_masthead' );

			include 'masthead.php';

			/**
			 * Fires after the masthead in the current template.
			 */
			do_action( 'qre_reports_after_masthead' );
			?>
			<div class="qre-reports-content">
				<?php
				the_content();
				?>
			</div>
		</div>
		<?php
	endwhile;
endif;
/**
 * After Quiz Reporting Dashboard page template content.
 *
 * Fires after the content of Quiz Reporting Dashboard page template.
 */
do_action( 'qre_dashboard_after_content' );
include 'footer.php';
