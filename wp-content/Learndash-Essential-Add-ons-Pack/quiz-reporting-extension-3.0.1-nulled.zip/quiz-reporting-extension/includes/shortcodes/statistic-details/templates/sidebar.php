<?php
/**
 * Template is used to show dashboard sidebar.
 *
 * @package Quiz Reporting Extension
 * @since 3.0.0
 */

$report_type = filter_input( INPUT_GET, 'report', FILTER_SANITIZE_STRING );
if ( empty( $report_type ) || ! in_array( $report_type, array( 'quiz', 'custom' ), true ) ) {
	$report_type = 'quiz';
}
?>
<div class="qre-reports-sidebar">
	<div class="qre-reports-sidebar-wrapper">
		<div class="sidebar-menu-items">
			<div class="sidebar-menu-item <?php echo 'quiz' === $report_type ? 'current' : ''; ?>">
				<a href="<?php echo esc_url( add_query_arg( 'report', 'quiz', get_permalink() ) ); ?>">
					<span class="icon"><img src="<?php echo esc_url( QRE_PLUGIN_URL . '/assets/public/images/chart1.svg' ); ?>"></span>
					<span>
						<?php
						/* translators: %s: Quiz Label */
						echo esc_html( sprintf( __( '%s Reports', 'quiz_reporting_learndash' ), learndash_get_custom_label( 'quiz' ) ) );
						?>
					</span>
				</a>
			</div>
			<div class="sidebar-menu-item <?php echo 'custom' === $report_type ? 'current' : ''; ?>">
				<a href="<?php echo esc_url( add_query_arg( 'report', 'custom', get_permalink() ) ); ?>">
					<span class="icon"><img src="<?php echo esc_url( QRE_PLUGIN_URL . '/assets/public/images/gear1.svg' ); ?>"></span>
					<span><?php esc_html_e( 'Custom Reports', 'quiz_reporting_learndash' ); ?></span>
				</a>
			</div>
			<div class="sidebar-menu-item filters">
				<?php
				if ( 'custom' === $report_type ) {
					echo Quiz_Reporting_Shortcode_Statistic_Details::show_custom_reports_filters();// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				}
				?>
			</div>
		</div>
	</div>
</div>
