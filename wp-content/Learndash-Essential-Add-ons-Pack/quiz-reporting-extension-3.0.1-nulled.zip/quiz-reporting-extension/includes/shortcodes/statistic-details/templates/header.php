<?php
/**
 * Template is used to show page template header.
 *
 * @package Quiz Reporting Extension
 * @since 3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="profile" href="http://gmpg.org/xfn/11">
		<?php
		wp_head();
		/**
		 * Fires in the head tag in focus mode.
		 */
		do_action( 'qre_reports_head' );
		?>
	</head>
	<body <?php body_class(); ?>>

		<div class="qre-reports-wrapper-class">
			<?php
				/**
				 * Filter Focus Mode sidebar collpases.
				 *
				 * @since 3.0.0
				 *
				 * @param bool false Wether to collapse Focus Mode sidebar. Default false.
				 */
			?>
			<div class="qre-reports <?php echo esc_attr( apply_filters( 'qre_dashboard_reports_collapse_sidebar', false ) ? 'qre-reports-sidebar-collapsed qre-reports-sidebar-filtered' : '' ); ?>">
				<?php
				/**
				 * Fires at the start of the focus template.
				 *
				 * @since 3.0.0
				 */
				do_action( 'qre_reports_template_start' ); ?>
