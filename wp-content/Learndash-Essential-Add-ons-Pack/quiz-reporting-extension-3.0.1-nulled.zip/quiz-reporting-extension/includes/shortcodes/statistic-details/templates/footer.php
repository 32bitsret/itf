<?php
/**
 * Template is used to show page template footer.
 *
 * @package Quiz Reporting Extension
 * @since 3.0.0
 */

					/**
					 * Fires after the assignments upload message.
					 *
					 * @since 3.0.0
					 */
					do_action( 'qre_reports_template_end' ); ?>
				</div> <!--/.quiz-reports-->
			</div> <!--/.qre-reports-wrapper-class-->
			<?php wp_footer(); ?>
	</body>
</html>
