<?php
/**
 * Handles all server side logic for the wdm_quiz_statistics_details Shortcode.
 *
 * @package Quiz Reporting Extension
 * @since 3.0.0
 */

if ( ( class_exists( 'Quiz_Reporting_Shortcode' ) ) && ( ! class_exists( 'Quiz_Reporting_Shortcode_Statistic_Details' ) ) ) {
	/**
	 * Class for handling LearnDash Course List Block
	 */
	class Quiz_Reporting_Shortcode_Statistic_Details extends Quiz_Reporting_Shortcode {

		/**
		 * Object constructor
		 */
		public function __construct() {
			$this->shortcode_slug = 'wdm_quiz_statistics_details';

			/**
			 * This array should be in the following format.
			 *
			 * $attributes = array(
			 *      'attr1' => array(
			 *          'type'      =>  'string',           // Types can be bool, string, array, object, float, integer.
			 *          'default'   =>  'Hello World!'
			 *      ),
			 *  )
			 *
			 * @var array
			 */
			$this->shortcode_attributes = array();
			$this->init();
		}

		/**
		 * Initialize the hooks.
		 */
		public function init() {
			add_shortcode( $this->shortcode_slug, array( $this, 'render_shortcode' ) );
			add_filter( 'qre_register_page_templates', array( $this, 'include_page_template' ), 10, 1 );
		}

		/**
		 * Render Shortcode
		 *
		 * This function is called per the add_shortcode() function above. This function will output
		 * the shortcode content. In the case of this function the rendered output will be for the
		 * [wdm_quiz_statistics_details] shortcode.
		 *
		 * @since 3.0.0
		 *
		 * @param array $attributes Shortcode attrbutes.
		 * @return string HTML content for the shortcode.
		 */
		public function render_shortcode( $attributes = array() ) {
			if ( isset( $_GET['_locale'] ) || is_admin() ) {// phpcs:ignore WordPress.Security.NonceVerification
				return;
			}
			$this->enqueue_shortcode_assets();
			ob_start();

			$this->add_breadcrumbs();

			$report_type = filter_input( INPUT_GET, 'report', FILTER_SANITIZE_STRING );
			if ( empty( $report_type ) || ! in_array( $report_type, array( 'quiz', 'custom' ), true ) ) {
				$report_type = 'quiz';
			}
			$screen_type = filter_input( INPUT_GET, 'screen', FILTER_SANITIZE_STRING );
			if ( empty( $screen_type ) || ! in_array( $screen_type, array( 'user', 'quiz' ), true ) ) {
				$screen_type = 'listing';
			}
			if ( 'quiz' === $report_type ) {
				switch ( $screen_type ) {
					case 'listing':
						echo $this->show_report_listing_screen();// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						break;
					case 'quiz':
						echo $this->show_single_statistic_screen();// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						break;
					case 'user':
						echo $this->show_user_statistics_screen();// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						break;
				}
			} elseif ( 'custom' === $report_type ) {
				echo $this->show_custom_reports_screen();// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			$content = ob_get_contents();
			ob_end_clean();
			return $content;
		}

		/**
		 * This method is used to show custom reports sidebar.
		 */
		public static function show_custom_reports_filters() {
			$categories     = maybe_unserialize( get_option( 'learndash_settings_courses_taxonomies', false ) );
			$filter_options = maybe_unserialize( get_user_meta( get_current_user_id(), 'qre_custom_reports_saved_query', true ) );
			$courses_label  = learndash_get_custom_label( 'courses' );
			$course_label   = learndash_get_custom_label( 'course' );
			$groups_label   = learndash_get_custom_label( 'groups' );
			$group_label    = learndash_get_custom_label( 'group' );
			$quizzes_label  = learndash_get_custom_label( 'quizzes' );
			$quiz_label     = learndash_get_custom_label( 'quiz' );
			$course_ids     = array();
			$group_ids      = array();
			if ( ! current_user_can( 'manage_options' ) ) {
				$user = wp_get_current_user();
				if ( in_array( 'group_leader', (array) $user->roles, true ) ) {
					$course_ids = qre_get_user_managed_group_courses();
					$group_ids  = learndash_get_administrators_group_ids( $user->ID );
				}
				if ( function_exists( 'ir_get_instructor_complete_course_list' ) && in_array( 'wdm_instructor', (array) $user->roles, true ) ) {
					$course_ids = array_merge( $course_ids, ir_get_instructor_complete_course_list( $user->ID ) );
				}
				$course_ids = array_merge( $course_ids, learndash_user_get_enrolled_courses( $user->ID, array(), true ) );
			}
			$quizzes_data = qre_search_quizzes();
			$course_ids   = Quiz_Export_Db::instance()->get_posts_within_ids( 'sfwd-courses', $course_ids );
			$group_ids    = Quiz_Export_Db::instance()->get_posts_within_ids( 'groups', $group_ids );
			$courses      = array_map(
				function( $course_id ) {
					if ( is_array( $course_id ) ) {
						$course_id = current( $course_id );
					}
					return get_post( $course_id );
				},
				$course_ids
			);
			$groups       = array_map(
				function( $group_id ) {
					if ( is_array( $group_id ) ) {
						$group_id = current( $group_id );
					}
					return get_post( $group_id );
				},
				$group_ids
			);
			$quizzes      = array_map(
				function( $quiz_item ) {
					return $quiz_item['post'];
				},
				$quizzes_data
			);

			$defaults = array(
				'category_filter'    => -1,
				'course_filter'      => -1,
				'enrollment_from'    => false,
				'enrollment_to'      => false,
				'completion_from'    => false,
				'completion_to'      => false,
				'course_title'       => 'yes',
				'completion_status'  => 'yes',
				'completion_date'    => false,
				'course_category'    => false,
				'enrollment_date'    => false,
				'course_progress'    => false,
				'group_filter'       => -1,
				'group_name'         => false,
				'user_name'          => 'yes',
				'user_email'         => false,
				'user_first_name'    => false,
				'user_last_name'     => false,
				'quiz_filter'        => -1,
				'quiz_status'        => 'yes',
				'quiz_title'         => 'yes',
				'quiz_category'      => 'yes',
				'quiz_points_total'  => 'yes',
				'quiz_points_earned' => 'yes',
				'quiz_score_percent' => 'yes',
				'date_of_attempt'    => 'yes',
				'time_taken'         => 'yes',
				'question_text'      => 'yes',
				'question_options'   => 'yes',
				'correct_answers'    => 'yes',
				'user_answers'       => 'yes',
				'question_type'      => 'yes',
			);
			if ( empty( $filter_options ) ) {
				$filter_options = array();
			} else {
				foreach ( $defaults as $keys => $defaults ) {
					if ( ! array_key_exists( $keys, $filter_options ) ) {
						$filter_options[ $keys ] = false;
					}
				}
			}
			$filter_options = wp_parse_args( $filter_options, $defaults );
			include QRE()::get_template( 'custom-fields.php' );
		}

		/**
		 * Show Custom Reports Export Screen.
		 *
		 * @return string Content HTML for Custom Reports Screen.
		 */
		public function show_custom_reports_screen() {
			ob_start();
			if ( ! is_user_logged_in() ) {
				?>
				<div class="qre_nodata_container">
					<div>
						<strong><?php esc_html_e( 'Access Denied.', 'quiz_reporting_learndash' ); ?></strong>
						<?php esc_html_e( 'You need to be logged in to access this page.', 'quiz_reporting_learndash' ); ?>
					</div>
				</div>
				<?php
				$content = ob_get_contents();
				ob_end_clean();
				return $content;
			}
			$categories     = maybe_unserialize( get_option( 'learndash_settings_courses_taxonomies', false ) );
			$filter_options = maybe_unserialize( get_user_meta( get_current_user_id(), 'qre_custom_reports_saved_query', true ) );
			$courses_label  = learndash_get_custom_label( 'courses' );
			$course_label   = learndash_get_custom_label( 'course' );
			$groups_label   = learndash_get_custom_label( 'groups' );
			$group_label    = learndash_get_custom_label( 'group' );
			$quizzes_label  = learndash_get_custom_label( 'quizzes' );
			$quiz_label     = learndash_get_custom_label( 'quiz' );
			$course_ids     = array();
			$group_ids      = array();
			if ( ! current_user_can( 'manage_options' ) ) {
				$user = wp_get_current_user();
				if ( in_array( 'group_leader', (array) $user->roles, true ) ) {
					$course_ids = qre_get_user_managed_group_courses();
					$group_ids  = learndash_get_administrators_group_ids( $user->ID );
				}
				if ( function_exists( 'ir_get_instructor_complete_course_list' ) && in_array( 'wdm_instructor', (array) $user->roles, true ) ) {
					$course_ids = array_merge( $course_ids, ir_get_instructor_complete_course_list( $user->ID ) );
				}
				$course_ids = array_merge( $course_ids, learndash_user_get_enrolled_courses( $user->ID, array(), true ) );
			}
			$quizzes_data = qre_search_quizzes();
			$course_ids   = Quiz_Export_Db::instance()->get_posts_within_ids( 'sfwd-courses', $course_ids );
			$group_ids    = Quiz_Export_Db::instance()->get_posts_within_ids( 'groups', $group_ids );
			$courses      = array_map(
				function( $course_id ) {
					if ( is_array( $course_id ) ) {
						$course_id = current( $course_id );
					}
					return get_post( $course_id );
				},
				$course_ids
			);
			$groups       = array_map(
				function( $group_id ) {
					if ( is_array( $group_id ) ) {
						$group_id = current( $group_id );
					}
					return get_post( $group_id );
				},
				$group_ids
			);
			$quizzes      = array_map(
				function( $quiz_item ) {
					return $quiz_item['post'];
				},
				$quizzes_data
			);

			$defaults = array(
				'category_filter'    => -1,
				'course_filter'      => -1,
				'enrollment_from'    => false,
				'enrollment_to'      => false,
				'completion_from'    => false,
				'completion_to'      => false,
				'course_title'       => 'yes',
				'completion_status'  => 'yes',
				'completion_date'    => false,
				'course_category'    => false,
				'enrollment_date'    => false,
				'course_progress'    => false,
				'group_filter'       => -1,
				'group_name'         => false,
				'user_name'          => 'yes',
				'user_email'         => false,
				'user_first_name'    => false,
				'user_last_name'     => false,
				'quiz_filter'        => -1,
				'quiz_status'        => 'yes',
				'quiz_title'         => 'yes',
				'quiz_category'      => 'yes',
				'quiz_points_total'  => 'yes',
				'quiz_points_earned' => 'yes',
				'quiz_score_percent' => 'yes',
				'date_of_attempt'    => 'yes',
				'time_taken'         => 'yes',
				'question_text'      => 'yes',
				'question_options'   => 'yes',
				'correct_answers'    => 'yes',
				'user_answers'       => 'yes',
				'question_type'      => 'yes',
			);
			if ( empty( $filter_options ) ) {
				$filter_options = array();
			} else {
				foreach ( $defaults as $keys => $defaults ) {
					if ( ! array_key_exists( $keys, $filter_options ) ) {
						$filter_options[ $keys ] = false;
					}
				}
			}
			$filter_options = wp_parse_args( $filter_options, $defaults );
			?>
			<div class="custom-reports-content">
				<?php
				/* translators: %s: Quiz Label */
				echo '<h2>' . esc_html( sprintf( __( '%s Results', 'quiz_reporting_learndash' ), $quiz_label ) ) . '</h2>';
				/* translators: %s: Quiz Label */
				echo '<p>' . esc_html( sprintf( __( 'Custom reports help you analyze %s results in a more detailed manner. Please select the filters you need from the left-side menu and click on \'Preview Report\' to display the reports here.', 'quiz_reporting_learndash' ), $quiz_label ) ) . '</p>';
				echo '<p><strong>' . esc_html__( 'Note:', 'quiz_reporting_learndash' ) . '</strong>' . esc_html__( 'It may take a while for the report to be generated depending on the amount of data selected.', 'quiz_reporting_learndash' ) . '</p>';
				?>
				<div class="sticky-custom-report-buttons">
					<button class="preview-data">
						<?php echo esc_html__( 'PREVIEW REPORT', 'quiz_reporting_learndash' ); ?>
					</button>
				</div>
				<div class="custom-report-buttons">
					<button class="preview-data">
						<?php echo esc_html__( 'PREVIEW REPORT', 'quiz_reporting_learndash' ); ?>
					</button>
				</div>
				<table id="custom-reports" style="display: none;">
					<thead>
					<tr>
						<?php
						if ( 'yes' === $filter_options['user_name'] ) {
							?>
							<th data-column="user_name"><?php echo esc_html( __( 'Username', 'quiz_reporting_learndash' ) ); ?></th>
							<?php
						}
						?>
						<?php
						if ( 'yes' === $filter_options['user_email'] ) {
							?>
							<th data-column="user_email"><?php echo esc_html( __( 'User Email', 'quiz_reporting_learndash' ) ); ?></th>
							<?php
						}
						?>
						<?php
						if ( 'yes' === $filter_options['quiz_title'] ) {
							?>
							<th data-column="quiz_title">
							<?php
							/* translators: %s: Quiz Label */
							echo esc_html( sprintf( __( '%s Title', 'quiz_reporting_learndash' ), learndash_get_custom_label( 'quiz' ) ) );
							?>
							</th>
							<?php
						}
						?>
						<?php
						if ( 'yes' === $filter_options['question_text'] ) {
							?>
							<th data-column="question_text">
							<?php
							/* translators: %s: Question Label */
							echo esc_html( sprintf( __( '%s Text', 'quiz_reporting_learndash' ), learndash_get_custom_label( 'question' ) ) );
							?>
							</th>
							<?php
						}
						?>
						<?php
						if ( 'yes' === $filter_options['quiz_status'] ) {
							?>
							<th data-column="quiz_status">
							<?php
							/* translators: %s: Quiz Label */
							echo esc_html( sprintf( __( '%s Status', 'quiz_reporting_learndash' ), learndash_get_custom_label( 'quiz' ) ) );
							?>
							</th>
							<?php
						}
						?>
						<?php
						if ( 'yes' === $filter_options['quiz_category'] ) {
							?>
							<th data-column="quiz_category">
							<?php
							/* translators: %s: Quiz Label */
							echo esc_html( sprintf( __( '%s Category', 'quiz_reporting_learndash' ), learndash_get_custom_label( 'quiz' ) ) );
							?>
							</th>
							<?php
						}
						?>
						<?php
						if ( 'yes' === $filter_options['quiz_points_total'] ) {
							?>
							<th data-column="quiz_points_total">
							<?php
							/* translators: %s: Quiz Label */
							echo esc_html( sprintf( __( '%s Total Points', 'quiz_reporting_learndash' ), learndash_get_custom_label( 'quiz' ) ) );
							?>
							</th>
							<?php
						}
						?>
						<?php
						if ( 'yes' === $filter_options['quiz_points_earned'] ) {
							?>
							<th data-column="quiz_points_earned">
							<?php
							/* translators: %s: Quiz Label */
							echo esc_html( sprintf( __( '%s Points Earned', 'quiz_reporting_learndash' ), learndash_get_custom_label( 'quiz' ) ) );
							?>
							</th>
							<?php
						}
						?>
						<?php
						if ( 'yes' === $filter_options['date_of_attempt'] ) {
							?>
							<th data-column="date_of_attempt"><?php echo esc_html( sprintf( __( 'Date of Attempt', 'quiz_reporting_learndash' ) ) ); ?></th>
							<?php
						}
						?>
						<?php
						if ( 'yes' === $filter_options['time_taken'] ) {
							?>
							<th data-column="time_taken"><?php echo esc_html( sprintf( __( 'Time Taken', 'quiz_reporting_learndash' ) ) ); ?></th>
							<?php
						}
						?>
						<?php
						if ( 'yes' === $filter_options['question_options'] ) {
							?>
							<th data-column="question_options">
							<?php
							/* translators: %s: Quiz Label */
							echo esc_html( sprintf( __( '%s Options', 'quiz_reporting_learndash' ), learndash_get_custom_label( 'question' ) ) );
							?>
							</th>
							<?php
						}
						?>
						<?php
						if ( 'yes' === $filter_options['correct_answers'] ) {
							?>
							<th data-column="correct_answers"><?php echo esc_html( __( 'Correct Answers', 'quiz_reporting_learndash' ) ); ?></th>
							<?php
						}
						?>
						<?php
						if ( 'yes' === $filter_options['user_answers'] ) {
							?>
							<th data-column="user_answers"><?php echo esc_html( __( 'User Answers', 'quiz_reporting_learndash' ) ); ?></th>
							<?php
						}
						?>
						<?php
						if ( 'yes' === $filter_options['question_type'] ) {
							?>
							<th data-column="question_type">
							<?php
							/* translators: %s: Question Label */
							echo esc_html( sprintf( __( '%s Type', 'quiz_reporting_learndash' ), learndash_get_custom_label( 'question' ) ) );
							?>
							</th>
							<?php
						}
						?>
						<?php
						if ( 'yes' === $filter_options['user_first_name'] ) {
							?>
							<th data-column="user_first_name"><?php echo esc_html( __( 'First Name', 'quiz_reporting_learndash' ) ); ?></th>
							<?php
						}
						?>
						<?php
						if ( 'yes' === $filter_options['user_last_name'] ) {
							?>
							<th data-column="user_last_name"><?php echo esc_html( __( 'Last Name', 'quiz_reporting_learndash' ) ); ?></th>
							<?php
						}
						?>
						<?php
						if ( 'yes' === $filter_options['course_title'] ) {
							?>
							<th data-column="course_title">
							<?php
							/* translators: %s: Course Label */
							echo esc_html( sprintf( __( '%s Title', 'quiz_reporting_learndash' ), learndash_get_custom_label( 'course' ) ) );
							?>
							</th>
							<?php
						}
						?>
						<?php
						if ( 'yes' === $filter_options['completion_status'] ) {
							?>
							<th data-column="completion_status"><?php echo esc_html( __( 'Completion Status', 'quiz_reporting_learndash' ) ); ?></th>
							<?php
						}
						?>
						<?php
						if ( 'yes' === $filter_options['completion_date'] ) {
							?>
							<th data-column="completion_date"><?php echo esc_html( __( 'Completion Date', 'quiz_reporting_learndash' ) ); ?></th>
							<?php
						}
						?>
						<?php
						if ( 'yes' === $filter_options['course_category'] ) {
							?>
							<th data-column="course_category">
							<?php
							/* translators: %s: Course Label */
							echo esc_html( sprintf( __( '%s Category', 'quiz_reporting_learndash' ), learndash_get_custom_label( 'course' ) ) );
							?>
							</th>
							<?php
						}
						?>
						<?php
						if ( 'yes' === $filter_options['course_progress'] ) {
							?>
							<th data-column="course_progress">
							<?php
							/* translators: %s: Course Label */
							echo esc_html( sprintf( __( '%s Progress', 'quiz_reporting_learndash' ), learndash_get_custom_label( 'course' ) ) );
							?>
							</th>
							<?php
						}
						?>
						<?php
						if ( 'yes' === $filter_options['enrollment_date'] ) {
							?>
							<th data-column="enrollment_date"><?php echo esc_html( __( 'Enrollment Date', 'quiz_reporting_learndash' ) ); ?></th>
							<?php
						}
						?>
						<?php
						if ( 'yes' === $filter_options['group_name'] ) {
							?>
							<th data-column="group_name">
							<?php
							/* translators: %s: Group Label */
							echo esc_html( sprintf( __( '%s Name', 'quiz_reporting_learndash' ), learndash_get_custom_label( 'group' ) ) );
							?>
							</th>
							<?php
						}
						?>
					</tr>
					</thead>
				</table>
			</div>
			<?php

			$content = ob_get_contents();
			ob_end_clean();
			return $content;
		}

		/**
		 * Show Single Statistics Screen.
		 *
		 * @return string Content HTML for User Screen.
		 */
		private function show_single_statistic_screen() {
			ob_start();
			if ( ! is_user_logged_in() ) {
				?>
				<div class="qre_nodata_container">
					<div>
						<strong><?php esc_html_e( 'Access Denied.', 'quiz_reporting_learndash' ); ?></strong>
						<?php esc_html_e( 'You need to be logged in to access this page.', 'quiz_reporting_learndash' ); ?>
					</div>
				</div>
				<?php
				$content = ob_get_contents();
				ob_end_clean();
				return $content;
			}

			$user_id          = filter_input( INPUT_GET, 'user', FILTER_VALIDATE_INT );
			$quiz_pro_id      = filter_input( INPUT_GET, 'quiz', FILTER_VALIDATE_INT );
			$statistic_ref_id = filter_input( INPUT_GET, 'statistic', FILTER_VALIDATE_INT );
			$user_id          = filter_input( INPUT_GET, 'user', FILTER_VALIDATE_INT );
			$referer          = filter_input( INPUT_GET, 'referer', FILTER_VALIDATE_URL );
			$query_type       = 'post';
			$quiz_id          = learndash_get_quiz_id_by_pro_quiz_id( $quiz_pro_id );
			if ( empty( $referer ) ) {
				$referer = get_permalink();
			}
			?>
			<a class="button back-button" href="<?php echo esc_url( $referer ); ?>"><?php echo esc_html__( 'BACK', 'quiz_reporting_learndash' ); ?></a>
			<?php
			include QRE()::get_template( 'user-introduction.php' );

			$resource_accessible = qre_check_if_accessible( $query_type, $quiz_id );
			if ( is_wp_error( $resource_accessible ) ) {
				?>
				<div class="qre_nodata_container">
					<div>
						<strong><?php esc_html_e( 'Access Denied.', 'quiz_reporting_learndash' ); ?></strong>
						<?php echo esc_html( $resource_accessible->get_error_message() ); ?>
					</div>
				</div>
				<?php
				$content = ob_get_contents();
				ob_end_clean();
				return $content;
			}
			if ( ! $resource_accessible ) {
				?>
				<div class="qre_nodata_container">
					<div>
						<strong><?php esc_html_e( 'Access Denied.', 'quiz_reporting_learndash' ); ?></strong>
						<?php esc_html_e( 'You do not have sufficient privileges to view this information.', 'quiz_reporting_learndash' ); ?>
					</div>
				</div>
				<?php
				$content = ob_get_contents();
				ob_end_clean();
				return $content;
			}

			$quiz_title         = get_the_title( $quiz_id );
			$attempt_data       = Quiz_Export_Db::instance()->get_statistic_summarized_data( $statistic_ref_id );
			$dt_current         = new \DateTime( '@0' );
			$dt_after_seconds   = new \DateTime( '@' . (int) $attempt_data['question_time'] );
			$time_taken         = $dt_current->diff( $dt_after_seconds )->format( '%H:%I:%S' );
			$percentage         = (int) $attempt_data['points'] / (int) $attempt_data['gpoints'] * 100;
			$quiz_post_settings = learndash_get_setting( $quiz_id );
			if ( ! is_array( $quiz_post_settings ) ) {
				$quiz_post_settings = array();
			}
			if ( ! isset( $quiz_post_settings['passingpercentage'] ) ) {
				$quiz_post_settings['passingpercentage'] = 0;
			}

			$passingpercentage = (float) number_format( $quiz_post_settings['passingpercentage'], 2 );
			$percentage        = (float) number_format( $percentage, 2 );
			$pass              = ( $percentage >= $passingpercentage ) ? __( 'PASS', 'quiz_reporting_learndash' ) : __( 'FAIL', 'quiz_reporting_learndash' );
			$class_average     = Quiz_Export_Data::instance()->get_quiz_class_average( $quiz_pro_id );
			?>
			<div class="quiz-title-container">
				<div class="quiz-title-label">
					<span class="label">
						<?php
						/* translators: %s: Quiz Label */
						echo esc_html( sprintf( __( '%s Title', 'quiz_reporting_learndash' ), learndash_get_custom_label( 'quiz' ) ) );
						?>
					</span>
				</div>
				<div class="quiz-title">
					<span><?php echo esc_html( $quiz_title ); ?></span>
				</div>
			</div>
			<div class="download-report">
				<span><?php echo esc_html__( 'Download Report', 'quiz_reporting_learndash' ); ?></span>
				<a href="#" data-ref_id="<?php echo esc_attr( $statistic_ref_id ); ?>" class="qre-export qre-download-csv">
					<img src="<?php echo esc_url( QRE_PLUGIN_URL . 'assets/public/images/csv.svg' ); ?>" />
				</a>
				<a href="#" data-ref_id="<?php echo esc_attr( $statistic_ref_id ); ?>" class="qre-export qre-download-xlsx">
					<img src="<?php echo esc_url( QRE_PLUGIN_URL . 'assets/public/images/xls.svg' ); ?>"/>
				</a>
			</div>
			<?php
			include QRE()::get_template( 'attempt-summary.php' );
			Quiz_Reporting_Frontend::instance()->display_attempted_questions( $user_id, $quiz_pro_id, $statistic_ref_id );
			$content = ob_get_contents();
			ob_end_clean();
			return $content;
		}

		/**
		 * Show User Statistics Screen.
		 *
		 * @return string Content HTML for User Screen.
		 */
		private function show_user_statistics_screen() {
			ob_start();
			if ( ! is_user_logged_in() ) {
				?>
				<div class="qre_nodata_container">
					<div>
						<strong><?php esc_html_e( 'Access Denied.', 'quiz_reporting_learndash' ); ?></strong>
						<?php esc_html_e( 'You need to be logged in to access this page.', 'quiz_reporting_learndash' ); ?>
					</div>
				</div>
				<?php
				$content = ob_get_contents();
				ob_end_clean();
				return $content;
			}

			$user_id        = filter_input( INPUT_GET, 'user', FILTER_VALIDATE_INT );
			$limit          = filter_input( INPUT_GET, 'limit', FILTER_VALIDATE_INT );
			$page           = filter_input( INPUT_GET, 'pageno', FILTER_VALIDATE_INT );
			$referer        = filter_input( INPUT_GET, 'referer', FILTER_VALIDATE_URL );
			$query_type     = 'user';
			$queried_string = '';
			$time_period    = false;
			$from_date      = false;
			$to_date        = false;
			$date_filter    = false;
			if ( empty( $referer ) ) {
				$referer = get_permalink();
			}
			?>
			<a class="button back-button" href="<?php echo esc_url( $referer ); ?>"><?php echo esc_html__( 'BACK', 'quiz_reporting_learndash' ); ?></a>
			<input type="hidden" name="user" value="<?php echo esc_attr( $user_id ); ?>" />
			<input type="hidden" name="screen" value="user" />
			<input type="hidden" name="report" value="quiz" />
			<input type="hidden" name="referer" value="<?php echo esc_url( $referer ); ?>">
			<?php
			include QRE()::get_template( 'user-introduction.php' );

			$resource_accessible = qre_check_if_accessible( $query_type, $user_id );
			if ( is_wp_error( $resource_accessible ) ) {
				?>
				<div class="qre_nodata_container">
					<div>
						<strong><?php esc_html_e( 'Access Denied.', 'quiz_reporting_learndash' ); ?></strong>
						<?php echo esc_html( $resource_accessible->get_error_message() ); ?>
					</div>
				</div>
				<?php
				$content = ob_get_contents();
				ob_end_clean();
				return $content;
			}
			if ( ! $resource_accessible ) {
				?>
				<div class="qre_nodata_container">
					<div>
						<strong><?php esc_html_e( 'Access Denied.', 'quiz_reporting_learndash' ); ?></strong>
						<?php esc_html_e( 'You do not have sufficient privileges to view this information.', 'quiz_reporting_learndash' ); ?>
					</div>
				</div>
				<?php
				$content = ob_get_contents();
				ob_end_clean();
				return $content;
			}
			echo $this->datatable_process_display( $query_type, $user_id, $queried_string, $date_filter, $time_period, $from_date, $to_date, $limit, $page );// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			$content = ob_get_contents();
			ob_end_clean();
			return $content;
		}

		/**
		 * Show Report Listing Screen.
		 *
		 * @return string Content HTML for Listing Screen.
		 */
		private function show_report_listing_screen() {
			ob_start();
			/* translators: %s: Quiz Label */
			echo '<h2>' . esc_html( sprintf( __( '%s Reports', 'quiz_reporting_learndash' ), learndash_get_custom_label( 'quiz' ) ) ) . '</h2>';

			include QRE()::get_template( 'quiz-filters.php' );

			if ( ! is_user_logged_in() ) {
				?>
				<div class="qre_nodata_container">
					<div>
						<strong><?php esc_html_e( 'Access Denied.', 'quiz_reporting_learndash' ); ?></strong>
						<?php esc_html_e( 'You need to be logged in to access this page.', 'quiz_reporting_learndash' ); ?>
					</div>
				</div>
				<?php
				$content = ob_get_contents();
				ob_end_clean();
				return $content;
			}

			$query_type     = filter_input( INPUT_GET, 'search_result_type', FILTER_SANITIZE_STRING );
			$queried_obj_id = filter_input( INPUT_GET, 'search_result_id', FILTER_VALIDATE_INT );
			$queried_string = filter_input( INPUT_GET, 'qre-search-field', FILTER_SANITIZE_STRING );
			$date_filter    = filter_input( INPUT_GET, 'filter_type', FILTER_SANITIZE_STRING );
			$time_period    = filter_input( INPUT_GET, 'period', FILTER_SANITIZE_STRING );
			$from_date      = filter_input( INPUT_GET, 'from_date', FILTER_SANITIZE_STRING );
			$to_date        = filter_input( INPUT_GET, 'to_date', FILTER_SANITIZE_STRING );
			$filter_nonce   = filter_input( INPUT_GET, 'qre_dashboard_filter_nonce', FILTER_SANITIZE_STRING );
			$limit          = filter_input( INPUT_GET, 'limit', FILTER_VALIDATE_INT );
			$page           = filter_input( INPUT_GET, 'pageno', FILTER_VALIDATE_INT );

			echo $this->datatable_process_display( $query_type, $queried_obj_id, $queried_string, $date_filter, $time_period, $from_date, $to_date, $limit, $page, $filter_nonce );// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			$content = ob_get_contents();
			ob_end_clean();
			return $content;
		}

		/**
		 * This method is used to fetch, process and display tabular information as per the input provided.
		 *
		 * @param  string  $query_type     Type of resource(user or quiz).
		 * @param  integer $queried_obj_id Resource ID.
		 * @param  string  $queried_string Search String.
		 * @param  string  $date_filter    Type of time filter.
		 * @param  string  $time_period    Relative time duration.
		 * @param  string  $from_date      From Date.
		 * @param  string  $to_date        To Date.
		 * @param  integer $limit          Stats per page.
		 * @param  integer $page           Page Number.
		 * @param  string  $filter_nonce   Filter Nonce.
		 * @return string Content HTML for Tabular Data.
		 */
		private function datatable_process_display( $query_type, $queried_obj_id, $queried_string, $date_filter, $time_period, $from_date, $to_date, $limit, $page, $filter_nonce = '' ) {
			ob_start();
			$statistics = Quiz_Export_Data::instance()->get_filtered_statistics( $query_type, $queried_obj_id, $queried_string, $date_filter, $time_period, $from_date, $to_date, $limit, $page );

			if ( is_wp_error( $statistics ) ) {
				?>
				<div class="qre_nodata_container">
					<div>
						<strong><?php esc_html_e( 'Access Denied.', 'quiz_reporting_learndash' ); ?></strong>
						<?php echo esc_html( $statistics->get_error_message() ); ?>
					</div>
				</div>
				<?php
				$content = ob_get_contents();
				ob_end_clean();
				return $content;
			}
			$total_count = (int) $statistics['total_count'];
			if ( empty( $page ) ) {
				$page = 1;
			}
			if ( empty( $limit ) ) {
				$limit = 10;
			}
			$pages = ceil( $total_count / $limit );
			if ( 0 === $pages ) {
				$pages = 1;
			}
			if ( $page > $pages ) {
				$page       = 1;
				$statistics = Quiz_Export_Data::instance()->get_filtered_statistics( $query_type, $queried_obj_id, $queried_string, $date_filter, $time_period, $from_date, $to_date, $limit, $page );
				if ( is_wp_error( $statistics ) ) {
					?>
					<div class="qre_nodata_container">
						<div>
							<strong><?php esc_html_e( 'Access Denied.', 'quiz_reporting_learndash' ); ?></strong>
							<?php echo esc_html( $statistics->get_error_message() ); ?>
						</div>
					</div>
					<?php
					$content = ob_get_contents();
					ob_end_clean();
					return $content;
				}
			}
			$statistic_data = array_map(
				function( $statistic ) {
					if ( ! is_array( $statistic ) || ! array_key_exists( 'statistic_ref_id', $statistic ) ) {
						return '';
					}
					$current_user         = wp_get_current_user();
					$user_managed_courses = qre_get_user_managed_group_courses();

					$is_user_accessible = qre_check_if_user_accessible( $statistic['user_id'], $current_user, $user_managed_courses );
					if ( ! $is_user_accessible || is_wp_error( $is_user_accessible ) ) {
						return '';
					}
					$is_quiz_accessible = qre_check_if_quiz_accessible( learndash_get_quiz_id_by_pro_quiz_id( $statistic['quiz_id'] ), $current_user, $user_managed_courses );
					if ( ! $is_quiz_accessible || is_wp_error( $is_quiz_accessible ) ) {
						return '';
					}
					global $wp;

					$referer      = urlencode( get_permalink() );
					$query_string = filter_input( INPUT_SERVER, 'QUERY_STRING', FILTER_SANITIZE_STRING );
					if ( ! empty( $query_string ) ) {
						$referer = urlencode( remove_query_arg( 'referer', add_query_arg( $query_string, '', home_url( $wp->request ) ) ) );
					}

					$data       = Quiz_Export_Db::instance()->get_statistic_summarized_data( $statistic['statistic_ref_id'] );
					$quiz_title = get_the_title( learndash_get_quiz_id_by_pro_quiz_id( $statistic['quiz_id'] ) );

					$data['quiz_title'] = "<a href='" . add_query_arg(
						array(
							'report'    => 'quiz',
							'screen'    => 'quiz',
							'user'      => $statistic['user_id'],
							'quiz'      => $statistic['quiz_id'],
							'statistic' => $statistic['statistic_ref_id'],
							'referer'   => $referer,
						),
						get_permalink()
					) . "'>" . $quiz_title . '</a>';

					$data['user_name']    = "<a href='" . add_query_arg(
						array(
							'report'  => 'quiz',
							'screen'  => 'user',
							'user'    => $statistic['user_id'],
							'referer' => $referer,
						),
						get_permalink()
					) . "'>" . get_userdata( $statistic['user_id'] )->display_name . '</a>';
					$data['date_attempt'] = date_i18n( get_option( 'date_format', 'd-M-Y' ), $statistic['create_time'] );
					/* translators: %1$d: Points Earned, %2$d: Total Points */
					$data['score'] = sprintf( __( '%1$d of %2$d', 'quiz_reporting_learndash' ), $data['points'], $data['gpoints'] );

					$dt_current         = new \DateTime( '@0' );
					$dt_after_seconds   = new \DateTime( '@' . (int) $data['question_time'] );
					$data['time_taken'] = $dt_current->diff( $dt_after_seconds )->format( '%H:%I:%S' );

					$data['link'] = "<a href='#' data-ref_id='" . $statistic['statistic_ref_id'] . "' class=\"qre-export qre-download-csv\"><img src='" . QRE_PLUGIN_URL . 'assets/public/images/csv.svg' . "'/></a><a href='#' data-ref_id='" . $statistic['statistic_ref_id'] . "' class=\"qre-export qre-download-xlsx\"><img src='" . QRE_PLUGIN_URL . 'assets/public/images/xls.svg' . "'/></a>";
					return $data;
				},
				$statistics
			);
			$statistic_data = remove_empty_array_items( $statistic_data );
			$data           = array();
			foreach ( $statistic_data as $statistic ) {
				$data[] = $statistic;
			}
			wp_localize_script(
				'qre_export_frontend',
				'quiz_statistics_data',
				array(
					'total'   => $total_count,
					'data'    => $data,
					'entries' => count( $data ),
					'no_data' => __( 'No Data to Display.', 'quiz_reporting_learndash' ),
				)
			);
			include QRE()::get_template( 'results-section.php' );
			$content = ob_get_contents();
			ob_end_clean();
			return $content;
		}

		/**
		 * This method is used to enqueue shortcode specific assets.
		 *
		 * @return void.
		 */
		private function enqueue_shortcode_assets() {
			wp_enqueue_script( 'qre_export_frontend' );
			wp_localize_script(
				'qre_export_frontend',
				'qre_export_obj',
				array(
					'search_results_nonce'    => wp_create_nonce( 'get_search_suggestions' ),
					'filtered_results_nonce'  => wp_create_nonce( 'filter_statistics_data' ),
					'quiz_export_nonce'       => wp_create_nonce( 'quiz_export-' . get_current_user_id() ),
					'custom_reports_nonce'    => wp_create_nonce( 'custom_reports_nonce' ),
					'fetch_custom_reports'    => wp_create_nonce( 'fetch_custom_reports' ),
					'ajax_url'                => admin_url( 'admin-ajax.php' ),
					'timeout_message'         => __( 'Request timed out. Please try again later.', 'quiz_reporting_learndash' ),
					'preview_report_btn_text' => __( 'APPLY FILTER & PREVIEW REPORT', 'quiz_reporting_learndash' ),
					'download_csv_text'       => __( 'DOWNLOAD CSV', 'quiz_reporting_learndash' ),
					'download_xls_text'       => __( 'DOWNLOAD XLSX', 'quiz_reporting_learndash' ),
				)
			);

			wp_enqueue_script( 'page_blocker' );
			wp_enqueue_style( 'qre_public_css' );
		}

		/**
		 * This method is used to add a page template for the shortcode via custom page template filter.
		 *
		 * @param  array $templates  List of templates.
		 * @return array            Updated List of page templates.
		 */
		public function include_page_template( $templates ) {
			$templates['shortcodes/statistic-details/templates/quiz-reports-dashboard.php'] = __( 'Quiz Dashboard Template', 'quiz_reporting_learndash' );
			return $templates;
		}

		/**
		 * This method is used to show breadcrumb on QRE shortcode pages.
		 */
		public function add_breadcrumbs() {
			$breadcrumbs = $this->get_breadcrumbs();
			if ( empty( $breadcrumbs ) ) {
				return;
			}
			echo '<div class=\'qre-breadcrumbs\'>';
			foreach ( $breadcrumbs as $breadcrumb ) {
				if ( empty( $breadcrumb['url'] ) ) {
					echo sprintf( '<span><strong>%s</strong></span>', esc_html( $breadcrumb['text'] ) );
					continue;
				}
				echo sprintf( '<a href="%1$s">%2$s</a>', esc_url( $breadcrumb['url'] ), esc_html( $breadcrumb['text'] ) );
			}
			echo '</div>';
		}

		/**
		 * This method is used to get breadcrumb elements for QRE shortcode navigation.
		 *
		 * @return array Array of Breadcrumb elements.
		 */
		public function get_breadcrumbs() {
			$breadcrumbs = array();
			$report_type = filter_input( INPUT_GET, 'report', FILTER_SANITIZE_STRING );
			if ( empty( $report_type ) || ! in_array( $report_type, array( 'quiz', 'custom' ), true ) ) {
				$report_type = 'quiz';
			}
			$screen_type = filter_input( INPUT_GET, 'screen', FILTER_SANITIZE_STRING );
			if ( empty( $screen_type ) || ! in_array( $screen_type, array( 'user', 'quiz' ), true ) ) {
				$screen_type = 'listing';
			}
			if ( 'custom' === $report_type ) {
				$breadcrumbs[] = array(
					'url'  => '',
					'text' => __( 'Custom Report Dashboard', 'quiz_reporting_learndash' ),
				);
				/**
				 * This filter is used to modify/change the breadcrumbs shown on Quiz Reporting Dashboard.
				 *
				 * @var array List of breadcrumb items.
				 */
				return apply_filters( 'qre_dashboard_breadcrumbs', $breadcrumbs );
			}
			switch ( $screen_type ) {
				case 'listing':
					$breadcrumbs[] = array(
						'url'  => '',
						/* translators: %s: Quiz Label */
						'text' => sprintf( __( '%s Reporting Dashboard', 'quiz_reporting_learndash' ), learndash_get_custom_label( 'quiz' ) ),
					);
					break;
				case 'user':
					$user_id = filter_input( INPUT_GET, 'user', FILTER_VALIDATE_INT );
					if ( empty( $user_id ) ) {
						$user_id = get_current_user_id();
					}
					$display_name  = get_userdata( $user_id )->display_name;
					$breadcrumbs[] = array(
						'url'  => add_query_arg( 'report', 'quiz', get_permalink() ),
						'text' => __( 'Home', 'quiz_reporting_learndash' ),
					);
					$breadcrumbs[] = array(
						'url'  => '',
						'text' => $display_name,
					);
					break;
				case 'quiz':
					$user_id = filter_input( INPUT_GET, 'user', FILTER_VALIDATE_INT );
					if ( empty( $user_id ) ) {
						$user_id = get_current_user_id();
					}
					$display_name = get_userdata( $user_id )->display_name;
					$quiz_pro_id  = filter_input( INPUT_GET, 'quiz', FILTER_VALIDATE_INT );
					$quiz_id      = learndash_get_quiz_id_by_pro_quiz_id( $quiz_pro_id );
					$referer      = urlencode( get_permalink() );
					$query_string = filter_input( INPUT_SERVER, 'QUERY_STRING', FILTER_SANITIZE_STRING );
					if ( ! empty( $query_string ) ) {
						$referer = urlencode(
							remove_query_arg(
								'referer',
								add_query_arg( $query_string, '', get_permalink() )
							)
						);
					}
					$breadcrumbs[] = array(
						'url'  => add_query_arg( 'report', 'quiz', get_permalink() ),
						'text' => __( 'Home', 'quiz_reporting_learndash' ),
					);
					$breadcrumbs[] = array(
						'url'  => add_query_arg(
							array(
								'report'  => 'quiz',
								'screen'  => 'user',
								'user'    => $user_id,
								'referer' => $referer,
							),
							get_permalink()
						),
						'text' => $display_name,
					);
					$breadcrumbs[] = array(
						'url'  => '',
						'text' => get_the_title( $quiz_id ),
					);
					break;
				default:
					$breadcrumbs[] = array(
						'url'  => add_query_arg( 'report', 'quiz', get_permalink() ),
						'text' => __( 'Home', 'quiz_reporting_learndash' ),
					);
					break;
			}
			/**
			 * This filter is used to modify/change the breadcrumbs shown on Quiz Reporting Dashboard.
			 *
			 * @var array List of breadcrumb items.
			 */
			return apply_filters( 'qre_dashboard_breadcrumbs', $breadcrumbs );
		}
	}
}
