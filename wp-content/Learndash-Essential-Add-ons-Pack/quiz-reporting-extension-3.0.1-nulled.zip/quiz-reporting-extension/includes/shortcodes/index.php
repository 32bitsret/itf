<?php
/**
 * Initiates all Shortcodes.
 *
 * @package Quiz Reporting Extension
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

require QRE_PLUGIN_DIR . 'includes/shortcodes/class-quiz-reporting-shortcode.php';

require QRE_PLUGIN_DIR . 'includes/shortcodes/statistic-details/class-quiz-reporting-shortcode-statistic-details.php';
