<?php
/**
 * Base class for all QRE Shprtcodes.
 *
 * @package Quiz Reporting Extension
 * @since 3.0.0
 */

if ( ! class_exists( 'Quiz_Reporting_Shortcode' ) ) {
	/**
	 * Abstract Parent class to hold common functions used by specific QRE Shortcodes.
	 */
	class Quiz_Reporting_Shortcode {

		/**
		 * Shortcode Name.
		 *
		 * @var string.
		 */
		protected $shortcode_slug;

		/**
		 * Shortcode Attributes.
		 *
		 * @var array.
		 */
		protected $shortcode_attributes;

		/**
		 * Constructor.
		 */
		public function __construct() {
		}

		/**
		 * Initialize the hooks.
		 */
		public function init() {
			add_shortcode( $this->shortcode_slug, array( $this, 'render_shortcode' ) );
		}

		/**
		 * Render Shortcode
		 *
		 * This method is called per the add_shortcode function above. This function will output
		 * the shortcode rendered content.
		 *
		 * @since 3.0.0
		 *
		 * @param array $attributes Shortcode attrbutes.
		 * @return void The output is echoed.
		 */
		public function render_shortcode( $attributes = array() ) {
		}

		/**
		 * Assign Default Values to Attributes.
		 *
		 * This method assigns default values to all arguments which are not passed.
		 * In strict mode, it checks the type for each attribute passed and overrides the value with default,
		 * if the type check fails.
		 *
		 * @param  array   $attributes Shortcode Attributes.
		 * @param  boolean $is_strict  Type checking.
		 * @return array    $attributes Shortcode Attributes.
		 */
		public function assign_defaults( $attributes = array(), $is_strict = false ) {
			$defaults   = array_column_ext( $this->shortcode_attributes, 'default', -1 );
			$attributes = shortcode_attributes( $defaults, $attributes );
			if ( $is_strict ) {
				$attributes = $this->check_argument_types( $attributes, $defaults );
			}
			return $attributes;
		}

		/**
		 * This method checks whether all the attributes have proper values assigned accoring to their types.
		 *
		 * @param  array $attributes Shortcode Attributes.
		 * @param  array $defaults   Default Values.
		 * @return array $attributes Shortcode Attributes.
		 */
		public function check_argument_types( $attributes, $defaults ) {
			$types = array_column_ext( $this->shortcode_attributes, 'type', -1 );
			foreach ( $attributes as $key => $value ) {
				if ( ! call_user_func( 'is_' . $types[ $key ], $value ) ) {
					// Assign default value if value passed isn't proper typed.
					$attributes[ $key ] = $defaults[ $key ];
				}
			}
			return $attributes;
		}
	}
}
