<?php
/**
 * This file is used to define pluggable functions.
 *
 * @package Quiz Reporting Extension.
 */

if ( ! function_exists( 'check_isset' ) ) {
	/**
	 * Checks variable and if isset true returns variable else ''
	 *
	 * @since     1.0.0
	 *
	 * @param array  $variable Input Array.
	 * @param string $parameter Key to check.
	 *
	 * @return variable or null
	 */
	function check_isset( $variable, $parameter ) {
		if ( isset( $variable[ $parameter ] ) ) {
			return $variable[ $parameter ];
		}
		return '';
	}
}

if ( ! function_exists( 'check_isset_var' ) ) {
	/**
	 * Verifies whether variable is set or empty
	 *
	 * @param  mixed $variable Variable to check.
	 * @return  $variable or ''
	 **/
	function check_isset_var( $variable ) {
		if ( isset( $variable ) ) {
			return $variable;
		}

		return '';
	}
}

if ( ! function_exists( 'remove_empty_array_items' ) ) {
	/**
	 * Remove_empty_array_items
	 * To get result
	 *
	 * @param  array $prevresult Input array.
	 * @return array $result Output array.
	 **/
	function remove_empty_array_items( $prevresult ) {
		if ( is_array( $prevresult ) ) {
			$result = array_filter( $prevresult );

			return $result;
		}

		return $prevresult;
	}
}

if ( ! function_exists( 'init_key_as_empty_array' ) ) {
	/**
	 * Return value of a particular key.
	 *
	 * @param array $arr_process_data Input array.
	 * @param int   $ref_id Key to check.
	 * @return mixed Value of the key or empty array.
	 */
	function init_key_as_empty_array( $arr_process_data, $ref_id ) {
		if ( ( ! isset( $arr_process_data[ $ref_id ] ) ) || ( ! is_array( $arr_process_data[ $ref_id ] ) ) ) {
			$arr_process_data[ $ref_id ] = array();
		}
		return $arr_process_data[ $ref_id ];
	}
}

if ( ! function_exists( 'get_protected_value' ) ) {

	/**
	 * [get_protected_value To access protected elements from the object as an array].
	 *
	 * @param object $obj  object to get protected fields.
	 * @param string $name field name from the object.
	 *
	 * @return [array] [associative array of an protected field]
	 */
	function get_protected_value( $obj, $name ) {
		$array  = (array) $obj;
		$prefix = chr( 0 ) . '*' . chr( 0 );

		return $array[ $prefix . $name ];
	}
}

if ( ! function_exists( 'array_column_ext' ) ) {
	/**
	 * An extended version of array_column that
	 * preserves the associated array key values if you give an $indexkey value of -1 to it.
	 *
	 * @param  array  $array     Input array.
	 * @param  string $columnkey Column to extract.
	 * @param  string $indexkey  Column to set as key for the output array.
	 * When you give an $indexkey value of -1 it preserves the associated array key values.
	 * @return array Output array.
	 */
	function array_column_ext( $array, $columnkey, $indexkey = null ) {
		$result = array();
		foreach ( $array as $subarray => $value ) {
			if ( array_key_exists( $columnkey, $value ) ) {
				$val = $array[ $subarray ][ $columnkey ];
			} elseif ( null === $columnkey ) {
				$val = $value;
			} else {
				continue;
			}

			if ( null === $indexkey ) {
				$result[] = $val;
			} elseif ( -1 === $indexkey || array_key_exists( $indexkey, $value ) ) {
				$result[ ( -1 === $indexkey ) ? $subarray : $array[ $subarray ][ $indexkey ] ] = $val;
			}
		}
		return $result;
	}
}

if ( ! function_exists( 'qre_search_quizzes' ) ) {
	/**
	 * Function is used to get quizzes that match the queried string.
	 *
	 * @param  string  $query Search Query.
	 * @param  boolean $skip_search Whether to skip searching and fetch all results.
	 * @return array   $results Search Results
	 */
	function qre_search_quizzes( $query = '', $skip_search = false ) {
		if ( ! is_user_logged_in() ) {
			return array();
		}
		$args = array(
			'post_type'      => 'sfwd-quiz',
			'posts_per_page' => -1,
		);
		if ( false === $skip_search ) {
			$args['s'] = $query;
		}
		$quizzes = get_posts( $args );
		if ( empty( $quizzes ) ) {
			return $quizzes;
		}
		// Filter out items for which user doesn't have access.
		$quizzes = array_filter(
			$quizzes,
			function( $quiz ) {
				$current_user         = wp_get_current_user();
				$user_managed_courses = qre_get_user_managed_group_courses();

				$is_quiz_accessible = qre_check_if_quiz_accessible( $quiz->ID, $current_user, $user_managed_courses );
				if ( ! $is_quiz_accessible || is_wp_error( $is_quiz_accessible ) ) {
					return false;
				}
				return true;
			}
		);
		$results = array_map(
			function( $quiz ) use ( $query ) {
				$item = array(
					'post'  => $quiz,
					'title' => $quiz->post_title,
					'type'  => 'post',
					'ID'    => $quiz->ID,
					'icon'  => 'quiz_icon',
				);
				return $item;
			},
			$quizzes
		);
		return $results;
	}
}

if ( ! function_exists( 'qre_search_users' ) ) {
	/**
	 * Function is used to get users that match the queried string.
	 *
	 * @param  string  $search_string Search Query.
	 * @param  boolean $skip_search Whether to skip searching and fetch all results.[WARNING: Skipping search isn't recommended. For systems that have large number of users, the system may crash due to memory shortage].
	 * @return array   $results Search Results.
	 */
	function qre_search_users( $search_string = '', $skip_search = false ) {
		if ( ! is_user_logged_in() ) {
			return array();
		}

		if ( false === $skip_search ) {
			$args        = array(
				'search'         => "*{$search_string}*",
				'search_columns' => array(
					'user_login',
					'user_nicename',
					'user_email',
				),
				'meta_query'     => array(
					'relation' => 'OR',
					array(
						'key'     => 'first_name',
						'value'   => $search_string,
						'compare' => 'LIKE',
					),
					array(
						'key'     => 'last_name',
						'value'   => $search_string,
						'compare' => 'LIKE',
					),
				),
			);
			$users       = new WP_User_Query( $args );
			$users_found = (array) $users->get_results();
		} else {
			$users_found = get_users();
		}
		if ( empty( $users_found ) ) {
			return $users_found;
		}
		// Filter out items for which user doesn't have access.
		$users_found = array_filter(
			$users_found,
			function( $user ) {
				$current_user         = wp_get_current_user();
				$user_managed_courses = qre_get_user_managed_group_courses();

				$is_user_accessible = qre_check_if_user_accessible( $user->ID, $current_user, $user_managed_courses );
				if ( ! $is_user_accessible || is_wp_error( $is_user_accessible ) ) {
					return false;
				}
				return true;
			}
		);
		$results     = array_map(
			function( $user ) use ( $search_string ) {
				$item = array(
					'user'  => $user,
					'title' => $user->display_name,
					'type'  => 'user',
					'ID'    => $user->ID,
					'icon'  => '',
				);
				if ( empty( $search_string ) ) {
					return $item;
				}
				$item['icon'] = 'user_icon';
				return $item;
			},
			$users_found
		);
		return $results;
	}
}

if ( ! function_exists( 'qre_get_user_managed_group_courses' ) ) {
	/**
	 * Get Courses of Groups where current user is the Group Leader.
	 *
	 * @return array User's Group affialiated Courses.
	 */
	function qre_get_user_managed_group_courses() {
		global $group_leader_managed_courses;
		$courses = array();
		$user    = wp_get_current_user();
		if ( ! in_array( 'group_leader', (array) $user->roles ) ) {// phpcs:ignore
			return $courses;
		}

		if ( isset( $group_leader_managed_courses ) && ! empty( $group_leader_managed_courses ) ) {
			return $group_leader_managed_courses;
		}

		$associated_groups = learndash_get_administrators_group_ids( get_current_user_id() );

		if ( ! empty( $associated_groups ) ) {
			foreach ( $associated_groups as $associated_group ) {
				if ( empty( $courses ) ) {
					$courses = learndash_group_enrolled_courses( $associated_group );
				} else {
					$courses = array_merge( $courses, learndash_group_enrolled_courses( $associated_group ) );
				}
			}
		}
		$group_leader_managed_courses = $courses;
		return $courses;
	}
}


if ( ! function_exists( 'qre_check_if_accessible' ) ) {
	/**
	 * Function is used to check whether the requested resource(user/lesson/topic/quiz) is accessible to the user.
	 *
	 * @param  string  $query_type     Requested Resource.
	 * @param  integer $queried_obj_id Resource ID.
	 * @return boolean/wp_error
	 */
	function qre_check_if_accessible( $query_type, $queried_obj_id ) {
		if ( ! in_array( $query_type, array( 'user', 'post' ), true ) ) {
			return new \WP_Error( 400, __( 'Invalid Resource Type.', 'quiz_reporting_learndash' ) );
		}
		$user                 = wp_get_current_user();
		$user_managed_courses = qre_get_user_managed_group_courses();
		if ( 'post' === $query_type ) {
			return qre_check_if_quiz_accessible( $queried_obj_id, $user, $user_managed_courses );
		}
		if ( 'user' === $query_type ) {
			return qre_check_if_user_accessible( $queried_obj_id, $user, $user_managed_courses );
		}
	}
}

if ( ! function_exists( 'qre_check_if_quiz_accessible' ) ) {
	/**
	 * This function is used to check whether the requested quiz is accessible by the user.
	 *
	 * @param  integer $queried_obj_id       Quiz ID.
	 * @param  WP_User $user                 User requesting resource.
	 * @param  array   $user_managed_courses User's Managed Courses(for Group Leaders).
	 * @return boolean/wp_error
	 */
	function qre_check_if_quiz_accessible( $queried_obj_id, $user, $user_managed_courses ) {
		$quiz_id = \Quiz_Export_Db::instance()->check_if_quiz_ids_actually_present( $queried_obj_id );
		if ( empty( $quiz_id ) ) {
			return new \WP_Error( 400, __( 'Invalid Request. Quiz ID doesn\'t exist.', 'quiz_reporting_learndash' ) );
		}
		// Check for Administrator.
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}
		$queried_course_id = learndash_get_course_id( $queried_obj_id );
		// Check for Group Leader.
		if ( ! empty( $user_managed_courses ) ) {
			if ( in_array( $queried_course_id, $user_managed_courses ) ) {// phpcs:ignore
				return true;
			}
		}
		// Check for Instructor.
		if ( function_exists( 'ir_get_instructor_complete_course_list' ) && in_array( 'wdm_instructor', (array) $user->roles, true ) ) {
			$instructor_course_ids = ir_get_instructor_complete_course_list( $user->ID );
			if ( in_array( $queried_course_id, $instructor_course_ids ) ) {// phpcs:ignore
				return true;
			}
		}
		$user_enrolled_course_ids = learndash_user_get_enrolled_courses( $user->ID, array(), true );
		// Check for Subscriber.
		if ( in_array( $queried_course_id, $user_enrolled_course_ids ) ) {// phpcs:ignore
			return true;
		}
		// Check if stats exist regardless of course enrollment.
		$pro_quiz_id    = get_post_meta( $queried_obj_id, 'quiz_pro_id', true );
		$existing_stats = \Quiz_Export_Db::instance()->get_all_statistic_ref_ids(
			array(
				'user_ids' => array( $user->ID ),
				'quiz_ids' => array( $pro_quiz_id ),
			)
		);
		if ( ! empty( $existing_stats ) ) {
			return true;
		}
		return false;
	}
}

if ( ! function_exists( 'qre_check_if_user_accessible' ) ) {
	/**
	 * This function is used to check whether the requested user info is accessible by the user.
	 *
	 * @param  integer $queried_obj_id       User ID.
	 * @param  WP_User $user                 User requesting resource.
	 * @param  array   $user_managed_courses User's Managed Courses(for Group Leaders).
	 * @return boolean/wp_error
	 */
	function qre_check_if_user_accessible( $queried_obj_id, $user, $user_managed_courses ) {
		$user_id = \Quiz_Export_Db::instance()->check_if_user_ids_actually_present( $queried_obj_id );
		if ( empty( $user_id ) ) {
			return new \WP_Error( 400, __( 'Invalid Request. User ID doesn\'t exist.', 'quiz_reporting_learndash' ) );
		}
		// Check for Administrator.
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}
		// Check for self Data.
		if ( (int) $queried_obj_id === $user->ID ) {
			return true;
		}
		// Check for Group Leader.
		if ( ! empty( $user_managed_courses ) ) {
			$user_managed_groups = learndash_get_administrators_group_ids( $user->ID );
			if ( ! empty( $user_managed_groups ) ) {
				foreach ( $user_managed_groups as $group_id ) {
					if ( in_array( $queried_obj_id, learndash_get_groups_user_ids( $group_id ) ) ) { // phpcs:ignore
						return true;
					}
				}
			}
		}
		// Check for Instructor.
		if ( function_exists( 'ir_get_instructor_complete_course_list' ) && in_array( 'wdm_instructor', (array) $user->roles, true ) ) {
			$instructor_course_ids    = ir_get_instructor_complete_course_list( $user->ID );
			$user_enrolled_course_ids = learndash_user_get_enrolled_courses( $queried_obj_id, array(), true );
			if ( ! empty( array_intersect( $instructor_course_ids, $user_enrolled_course_ids ) ) ) {
				return true;
			}
		}
		return false;
	}
}
