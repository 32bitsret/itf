<?php
/**
 * Plugin Name: Quiz Reporting Extension for LearnDash
 * Plugin URI: http://wisdmlabs.com/
 * Description: To export quiz data. The plugin exports single/all quiz data in .xlsx and .csv files.
 * Version: 3.0.1
 * Author: WisdmLabs
 * Author URI: http://wisdmlabs.com/
 * Text Domain:       quiz_reporting_learndash
 * Domain Path:       /languages
 *
 * @package Quiz Reporting Extension
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! defined( 'QRE_PLUGIN_FILE' ) ) {
	define( 'QRE_PLUGIN_FILE', __FILE__ );
}

// Include the main QRE class.
if ( ! class_exists( 'QuizReportingExtension', false ) ) {
	include_once dirname( QRE_PLUGIN_FILE ) . '/includes/class-quiz-reporting-extension.php';
}

if ( ! function_exists( 'QRE' ) ) {
	/**
	 * Returns the main instance of QRE.
	 *
	 * @since  2.1
	 * @return QuizReportingExtension
	 */
	function QRE() { // phpcs:ignore WordPress.NamingConventions.ValidFunctionName.FunctionNameInvalid
		return Quiz_Reporting_Extension::instance();
	}
}
$GLOBALS['qre'] = QRE();
