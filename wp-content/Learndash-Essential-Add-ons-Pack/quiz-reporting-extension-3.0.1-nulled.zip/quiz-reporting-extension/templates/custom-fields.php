<?php
/**
 * Template is used to show Custom Reports Field selection.
 *
 * @package Quiz Reporting Extension
 * @since 3.0.0
 */

?>
<div class="custom-report-filters">
	<div class="section-container">
		<?php if ( $categories && ( in_array( 'ld_course_category', $categories, true ) && 'yes' === $categories['ld_course_category'] ) ) : ?>
			<div class="section">
				<?php
				$category_terms = get_terms(
					array(
						'hide_empty' => false,
						'taxonomy'   => 'ld_course_category',
					)
				);
				?>
				<div class="section-heading"><?php esc_html_e( 'Categories', 'quiz_reporting_learndash' ); ?></div>
				<div class="section-body">
					<select class="custom-filter" name="category_filter" id="category_filter">
						<option value="-1" <?php selected( $filter_options['category_filter'], -1 ); ?>><?php esc_html_e( 'All', 'quiz_reporting_learndash' ); ?></option>
						<?php foreach ( $category_terms as $category ) : ?>
							<option value="<?php echo esc_attr( $category->term_id ); ?>" <?php selected( $filter_options['category_filter'], $category->term_id ); ?>><?php echo esc_html( $category->name ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>
		<?php endif; ?>
		<div class="section">
			<div class="section-heading">
				<?php echo esc_html( $courses_label ); ?>
				<span class="section-control expanded"></span>
			</div>
			<div class="section-body expanded">
				<select class="custom-filter" name="course_filter" id="course_filter">
					<option value="-1" <?php selected( $filter_options['course_filter'], -1 ); ?>><?php esc_html_e( 'All', 'quiz_reporting_learndash' ); ?></option>
					<?php foreach ( $courses as $course ) : ?>
						<option value="<?php echo esc_attr( $course->ID ); ?>" <?php selected( $filter_options['course_filter'], $course->ID ); ?>><?php echo esc_html( $course->post_title ); ?></option>
					<?php endforeach; ?>
				</select>
				<div class="date-filters">
					<span class="label">
						<?php esc_html_e( 'Enroll date', 'quiz_reporting_learndash' ); ?>
					</span>
					<input class="date_picker" type="text" name="enrollment_from" placeholder="<?php esc_attr_e( 'From', 'quiz_reporting_learndash' ); ?>" />
					<input class="date_picker" type="text" name="enrollment_to" placeholder="<?php esc_attr_e( 'To', 'quiz_reporting_learndash' ); ?>" />
				</div>
				<div class="date-filters">
					<span class="label">
						<?php
						/* translators: %s: Course Label */
						echo esc_html( sprintf( __( '%s completion date', 'quiz_reporting_learndash' ), $course_label ) );
						?>
					</span>
					<input class="date_picker" type="text" name="completion_from" placeholder="<?php esc_attr_e( 'From', 'quiz_reporting_learndash' ); ?>" />
					<input class="date_picker" type="text" name="completion_to" placeholder="<?php esc_attr_e( 'To', 'quiz_reporting_learndash' ); ?>" />
				</div>
				<div class="field-selector">
					<span class="label">
						<?php esc_html_e( 'Fields', 'quiz_reporting_learndash' ); ?>
					</span>
					<div>
						<input type="checkbox" name="course_title" id="course_title" value="yes" <?php checked( $filter_options['course_title'], 'yes' ); ?> />
						<label for="course_title">
							<?php echo esc_html( $course_label ); ?>
						</label>
					</div>
					<div>
						<input type="checkbox" name="completion_status" id="completion_status" value="yes" <?php checked( $filter_options['completion_status'], 'yes' ); ?> />
						<label for="completion_status">
							<?php
							/* translators: %s : Course Label. */
							echo esc_html( sprintf( __( '%s Completion Status', 'quiz_reporting_learndash' ), $course_label ) );
							?>
						</label>
					</div>
					<div>
						<input type="checkbox" name="completion_date" id="completion_date" value="yes" <?php checked( $filter_options['completion_date'], 'yes' ); ?> />
						<label for="completion_date">
							<?php
							/* translators: %s : Course Label. */
							echo esc_html( sprintf( __( '%s Completion Date', 'quiz_reporting_learndash' ), $course_label ) );
							?>
						</label>
					</div>
					<div>
						<input type="checkbox" name="course_category" id="course_category" value="yes" <?php checked( $filter_options['course_category'], 'yes' ); ?> />
						<label for="course_category">
							<?php
							/* translators: %s : Course Label. */
							echo esc_html( sprintf( __( '%s Category', 'quiz_reporting_learndash' ), $course_label ) );
							?>
						</label>
					</div>
					<div>
						<input type="checkbox" name="enrollment_date" id="enrollment_date" value="yes" <?php checked( $filter_options['enrollment_date'], 'yes' ); ?> />
						<label for="enrollment_date">
							<?php
							echo esc_html( __( 'Enrollment Date', 'quiz_reporting_learndash' ) );
							?>
						</label>
					</div>
					<div>
						<input type="checkbox" name="course_progress" id="course_progress" value="yes" <?php checked( $filter_options['course_progress'], 'yes' ); ?> />
						<label for="course_progress">
							<?php
							/* translators: %s : Course Label. */
							echo esc_html( sprintf( __( '%s Progress', 'quiz_reporting_learndash' ), $course_label ) );
							?>
						</label>
					</div>
				</div>
			</div>
		</div>
		<div class="section">
			<div class="section-heading">
				<?php echo esc_html( $groups_label ); ?>
				<span class="section-control"></span>
			</div>
			<div class="section-body">
				<select class="custom-filter" name="group_filter" id="group_filter">
					<option value="-1" <?php selected( $filter_options['group_filter'], -1 ); ?>><?php esc_html_e( 'All', 'quiz_reporting_learndash' ); ?></option>
					<?php foreach ( $groups as $group ) : ?>
						<option value="<?php echo esc_attr( $group->ID ); ?>" <?php selected( $filter_options['group_filter'], $group->ID ); ?>><?php echo esc_html( $group->post_title ); ?></option>
					<?php endforeach; ?>
				</select>
				<div class="field-selector">
					<div>
						<span class="label">
							<?php esc_html_e( 'Fields', 'quiz_reporting_learndash' ); ?>
						</span>
						<input type="checkbox" name="group_name" id="group_name" value="yes" <?php checked( $filter_options['group_name'], 'yes' ); ?> />
						<label for="group_name">
							<?php echo esc_html( $group_label ); ?>
						</label>
					</div>
				</div>
			</div>
		</div>
		<div class="section">
			<div class="section-heading">
				<?php echo esc_html__( 'Users', 'quiz_reporting_learndash' ); ?>
				<span class="section-control"></span>
			</div>
			<div class="section-body">
				<div class="field-selector">
					<span class="label">
						<?php esc_html_e( 'Fields', 'quiz_reporting_learndash' ); ?>
					</span>
					<div>
						<input type="checkbox" name="user_name" id="user_name" value="yes" <?php checked( $filter_options['user_name'], 'yes' ); ?> />
						<label for="user_name">
							<?php echo esc_html__( 'User Name', 'quiz_reporting_learndash' ); ?>
						</label>
					</div>
					<div>
						<input type="checkbox" name="user_email" id="user_email" value="yes" <?php checked( $filter_options['user_email'], 'yes' ); ?> />
						<label for="user_email">
							<?php echo esc_html__( 'User Email', 'quiz_reporting_learndash' ); ?>
						</label>
					</div>
					<div>
						<input type="checkbox" name="user_first_name" id="user_first_name" value="yes" <?php checked( $filter_options['user_first_name'], 'yes' ); ?> />
						<label for="user_first_name">
							<?php echo esc_html__( 'First Name', 'quiz_reporting_learndash' ); ?>
						</label>
					</div>
					<div>
						<input type="checkbox" name="user_last_name" id="user_last_name" value="yes" <?php checked( $filter_options['user_last_name'], 'yes' ); ?> />
						<label for="user_last_name">
							<?php echo esc_html__( 'Last Name', 'quiz_reporting_learndash' ); ?>
						</label>
					</div>
				</div>
			</div>
		</div>
		<div class="section">
			<div class="section-heading">
				<?php echo esc_html( $quizzes_label ); ?>
				<span class="section-control"></span>
			</div>
			<div class="section-body">
				<select class="custom-filter" name="quiz_filter" id="quiz_filter">
					<option value="-1" <?php selected( $filter_options['quiz_filter'], -1 ); ?>><?php esc_html_e( 'All', 'quiz_reporting_learndash' ); ?></option>
					<?php foreach ( $quizzes as $quiz ) : ?>
						<option value="<?php echo esc_attr( $quiz->ID ); ?>" <?php selected( $filter_options['quiz_filter'], $quiz->ID ); ?>><?php echo esc_html( $quiz->post_title ); ?></option>
					<?php endforeach; ?>
				</select>
				<div class="field-selector">
					<span class="label">
						<?php esc_html_e( 'Fields', 'quiz_reporting_learndash' ); ?>
					</span>
					<div>
						<input type="checkbox" name="quiz_title" id="quiz_title" value="yes" <?php checked( $filter_options['quiz_title'], 'yes' ); ?> />
						<label for="quiz_title">
							<?php
							/* translators: %s: Quiz Label */
							echo esc_html( sprintf( __( '%s Title', 'quiz_reporting_learndash' ), $quiz_label ) );
							?>
						</label>
					</div>
					<div>
						<input type="checkbox" name="quiz_status" id="quiz_status" value="yes" <?php checked( $filter_options['quiz_status'], 'yes' ); ?> />
						<label for="quiz_status">
							<?php
							/* translators: %s: Quiz Label */
							echo esc_html( sprintf( __( '%s Status', 'quiz_reporting_learndash' ), $quiz_label ) );
							?>
						</label>
					</div>
					<div>
						<input type="checkbox" name="quiz_category" id="quiz_category" value="yes" <?php checked( $filter_options['quiz_category'], 'yes' ); ?> />
						<label for="quiz_category">
							<?php
							/* translators: %s: Quiz Label */
							echo esc_html( sprintf( __( '%s Category', 'quiz_reporting_learndash' ), $quiz_label ) );
							?>
						</label>
					</div>
					<div>
						<input type="checkbox" name="quiz_points_total" id="quiz_points_total" value="yes" <?php checked( $filter_options['quiz_points_total'], 'yes' ); ?> />
						<label for="quiz_points_total">
							<?php echo esc_html__( 'Total Points', 'quiz_reporting_learndash' ); ?>
						</label>
					</div>
					<div>
						<input type="checkbox" name="quiz_points_earned" id="quiz_points_earned" value="yes" <?php checked( $filter_options['quiz_points_earned'], 'yes' ); ?> />
						<label for="quiz_points_earned">
							<?php echo esc_html__( 'Points Earned', 'quiz_reporting_learndash' ); ?>
						</label>
					</div>
					<div>
						<input type="checkbox" name="quiz_score_percent" id="quiz_score_percent" value="yes" <?php checked( $filter_options['quiz_score_percent'], 'yes' ); ?> />
						<label for="quiz_score_percent">
							<?php echo esc_html__( 'Score(in %)', 'quiz_reporting_learndash' ); ?>
						</label>
					</div>
					<div>
						<input type="checkbox" name="date_of_attempt" id="date_of_attempt" value="yes" <?php checked( $filter_options['date_of_attempt'], 'yes' ); ?> />
						<label for="date_of_attempt">
							<?php echo esc_html__( 'Date of Attempt', 'quiz_reporting_learndash' ); ?>
						</label>
					</div>
					<div>
						<input type="checkbox" name="time_taken" id="time_taken" value="yes" <?php checked( $filter_options['time_taken'], 'yes' ); ?> />
						<label for="time_taken">
							<?php echo esc_html__( 'Time Taken', 'quiz_reporting_learndash' ); ?>
						</label>
					</div>
					<div>
						<input type="checkbox" name="question_text" id="question_text" value="yes" <?php checked( $filter_options['question_text'], 'yes' ); ?> />
						<label for="question_text">
							<?php echo esc_html__( 'Question Text', 'quiz_reporting_learndash' ); ?>
						</label>
					</div>
					<div>
						<input type="checkbox" name="question_options" id="question_options" value="yes" <?php checked( $filter_options['question_options'], 'yes' ); ?> />
						<label for="question_options">
							<?php echo esc_html__( 'Question Options', 'quiz_reporting_learndash' ); ?>
						</label>
					</div>
					<div>
						<input type="checkbox" name="correct_answers" id="correct_answers" value="yes" <?php checked( $filter_options['correct_answers'], 'yes' ); ?> />
						<label for="correct_answers">
							<?php echo esc_html__( 'Correct Answers', 'quiz_reporting_learndash' ); ?>
						</label>
					</div>
					<div>
						<input type="checkbox" name="user_answers" id="user_answers" value="yes" <?php checked( $filter_options['user_answers'], 'yes' ); ?> />
						<label for="user_answers">
							<?php echo esc_html__( 'User Answers', 'quiz_reporting_learndash' ); ?>
						</label>
					</div>
					<div>
						<input type="checkbox" name="question_type" id="question_type" value="yes" <?php checked( $filter_options['question_type'], 'yes' ); ?> />
						<label for="question_type">
							<?php echo esc_html__( 'Question Type', 'quiz_reporting_learndash' ); ?>
						</label>
					</div>
				</div>
			</div>
		</div>
		<div class="section" style="display: none;">
			<div class="section-body expanded">
				<button class="save_config"><?php esc_html_e( 'Apply Filters', 'quiz_reporting_learndash' ); ?></button>
			</div>
		</div>
	</div>
</div>
<?php
