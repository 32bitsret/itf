<?php
/**
 * Template is used to show filtering options for reports.
 *
 * @package Quiz Reporting Extension
 * @since 3.0.0
 */

?>

<form method="GET">
	<div class="quiz-report-filters">
		<div class="filter-option search-reports">
			<label for="qre-search-field"><?php echo esc_html__( 'Search', 'quiz_reporting_learndash' ); ?></label>
			<?php $search_field = filter_input( INPUT_GET, 'qre-search-field', FILTER_SANITIZE_STRING ); ?>
			<?php /* translators: %s: Quiz Custom Label */ ?>
			<input type="text" name="qre-search-field" id="qre-search-field" placeholder="<?php echo esc_attr( sprintf( _x( 'Student Name, %s Title', 'Search Placeholder', 'quiz_reporting_learndash' ), learndash_get_custom_label( 'quiz' ) ) ); ?>" autocomplete="off" maxlength="50" value="<?php echo esc_attr( $search_field ); ?>" />
			<?php
			if ( ! empty( $search_field ) ) {
				?>
				<span class="reset_search"></span>
				<?php
			}
			?>
		</div>
		<?php $filter_type = filter_input( INPUT_GET, 'filter_type', FILTER_SANITIZE_STRING ); ?>
		<div class="filter-option date-filter <?php echo ! empty( $filter_type ) ? 'toggleon' : ''; ?>">
			<div class="toggle">
				<span class="label"><?php echo esc_html__( 'Attempt:', 'quiz_reporting_learndash' ); ?></span>
				<span class="option <?php echo empty( $filter_type ) ? 'active' : ''; ?>"><?php echo esc_html__( 'Period', 'quiz_reporting_learndash' ); ?></span>
				<label class="switch">
					<input type="checkbox" name="filter_type" <?php checked( $filter_type, 'on' ); ?> />
					<div class="slider round"></div>
				</label>
				<span class="option <?php echo ! empty( $filter_type ) ? 'active' : ''; ?>"><?php echo esc_html__( 'Date Range', 'quiz_reporting_learndash' ); ?></span>	
			</div>
			<div class="input">
				<?php $duration = filter_input( INPUT_GET, 'period', FILTER_SANITIZE_STRING ); ?>
				<select class="period" name="period">
					<option value="year" <?php selected( $duration, 'year' ); ?>><?php esc_html_e( 'Last 1 year', 'quiz_reporting_learndash' ); ?></option>
					<option value="month" <?php selected( $duration, 'month' ); ?>><?php esc_html_e( 'Last 1 month', 'quiz_reporting_learndash' ); ?></option>
					<option value="week" <?php selected( $duration, 'week' ); ?>><?php esc_html_e( 'Last 1 week', 'quiz_reporting_learndash' ); ?></option>
					<option value="day" <?php selected( $duration, 'day' ); ?>><?php esc_html_e( 'Last 1 day', 'quiz_reporting_learndash' ); ?></option>
				</select>
				<?php $from_date = filter_input( INPUT_GET, 'from_date', FILTER_SANITIZE_STRING ); ?>
				<input type="text" name="from_date" class="range" placeholder="<?php echo esc_attr__( 'From', 'quiz_reporting_learndash' ); ?>" value="<?php echo esc_attr( $from_date ); ?>" autocomplete="off"/>
				<?php $to_date = filter_input( INPUT_GET, 'to_date', FILTER_SANITIZE_STRING ); ?>
				<input type="text" name="to_date" class="range" placeholder="<?php echo esc_attr__( 'To', 'quiz_reporting_learndash' ); ?>" value="<?php echo esc_attr( $to_date ); ?>" autocomplete="off" />
			</div>
		</div>
		<div class="filter-results">
			<?php $search_result_type = filter_input( INPUT_GET, 'search_result_type', FILTER_SANITIZE_STRING ); ?>
			<input type="hidden" name="search_result_type" class="search_result_type" value="<?php echo esc_attr( $search_result_type ); ?>" />
			<?php $search_result_id = filter_input( INPUT_GET, 'search_result_id', FILTER_VALIDATE_INT ); ?>
			<input type="hidden" name="search_result_id" class="search_result_id" value="<?php echo esc_attr( $search_result_id ); ?>" />
			<?php wp_nonce_field( 'filter_quiz_results', 'qre_dashboard_filter_nonce', false ); ?>
			<button class="show-reports"><?php echo esc_html__( 'Show Reports', 'quiz_reporting_learndash' ); ?></button>
		</div>
	</div>
</form>
