<?php
/**
 * Template is used to show quiz table on the frontend shortcode..
 *
 * @package Quiz Reporting Extension
 * @since 3.0.0
 */

?>
<div class="qre_quiz_data" data-counter="">
	<div><center><?php esc_html_e( 'No Data to display', 'quiz_reporting_learndash' ); ?></center></div>
</div>
