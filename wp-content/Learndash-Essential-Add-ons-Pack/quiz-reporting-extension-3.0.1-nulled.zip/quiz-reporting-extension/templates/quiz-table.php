<?php
/**
 * Template is used to show quiz table on the frontend shortcode..
 *
 * @package Quiz Reporting Extension
 * @since 3.0.0
 *
 * =====================================================================================
 * Variables available.
 *
 * $user_id : User ID.
 * $qre_group_courses : Group Courses.
 * $quiz : Quizzes Data.
 * $per_page : PerPage class instance.
 * $rowcount : Row Count.
 * $page : Page Number.
 * $start : Loop Start.
 * $end : Loop End.
 * $perpageresult: Pagination HTML.
 * =====================================================================================
 */

?>
<div id="pagination" style="float:right">
	<?php echo $perpageresult; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
</div>
<input type="hidden" id="rowcount" name="rowcount" value="<?php echo esc_attr( $rowcount ); ?>" />
<?php
$all_ids = array();
for ( $count = $start; $count < $end; ++$count ) {
	$quiz_course          = learndash_get_course_id( $quiz[ $count ]['quiz'] );
	$download_report_link = "<a href='#' data-ref_id='" . $quiz[ $count ]['statistic_ref_id'] . "' class=\"qre-export  qre-download-csv\">CSV</a>&nbsp;&#8226;&nbsp;<a href='#' data-ref_id='" . $quiz[ $count ]['statistic_ref_id'] . "' class=\"qre-export  qre-download-xlsx\">Excel</a>";
	if ( current_user_can( 'group_leader' ) && get_current_user_id() !== $user_id ) {
		if ( '' === $quiz_course ) {
			$quiz_course = $quiz[ $count ]['course'];
		}
		if ( ! empty( $quiz_course ) && in_array( $quiz_course, $qre_group_courses ) && ! empty( $qre_group_courses ) ) {
			$quiz_title      = get_the_title( $quiz[ $count ]['quiz'] );
			$quiz_time       = $quiz[ $count ]['time'];
			$date_format     = get_option( 'date_format', 'd-M-Y' );
			$quiz_date       = date( $date_format, $quiz_time );// phpcs:ignore
			$quiz_percentage = $quiz[ $count ]['percentage'];
			?>
			<div class="qre_quiz_data" data-counter="<?php echo esc_attr( $count ); ?>">
				<div class="qrecolumn_1 columns">
					<input type="hidden" value="<?php echo esc_attr( $quiz[ $count ]['time'] ); ?>" class="details_id">
					<input type="hidden" value="<?php echo esc_attr( $quiz[ $count ]['quiz'] ); ?>" class="quiz_ids">
					<input type="hidden" value="<?php echo esc_attr( $quiz[ $count ]['statistic_ref_id'] ); ?>" class="stat_ref_id">
					<a href="javascript:void(0)" style="text-decoration:none;" class="quiz_load"><?php echo esc_html( $quiz_title ); ?></a>
				</div>
				<div class="qrecolumn_2 columns">
					<?php echo esc_html( $quiz_date ); ?>
				</div>
				<div class="qrecolumn_3 columns">
					<?php echo esc_html( $quiz_percentage ) . '%'; ?>
				</div>
				<div class="qrecolumn_4 columns">
					<?php echo $download_report_link; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
			</div>
			<div class="qre_prev_div" id="qre_quiz_details_<?php echo esc_attr( $count ); ?>"></div>
			<?php
		}
	} else {
		$quiz_title      = get_the_title( $quiz[ $count ]['quiz'] );
		$quiz_time       = $quiz[ $count ]['time'];
		$date_format     = get_option( 'date_format', 'd-M-Y' );
		$quiz_date       = date( $date_format, $quiz_time );// phpcs:ignore
		$quiz_percentage = $quiz[ $count ]['percentage'];
		?>
		<div class="qre_quiz_data" data-counter="<?php echo esc_attr( $count ); ?>">
			<div class="qrecolumn_1 columns">
				<input type="hidden" value="<?php echo esc_attr( $quiz[ $count ]['time'] ); ?>" class="details_id">
				<input type="hidden" value="<?php echo esc_attr( $quiz[ $count ]['quiz'] ); ?>" class="quiz_ids">
				<input type="hidden" value="<?php echo esc_attr( $quiz[ $count ]['statistic_ref_id'] ); ?>" class="stat_ref_id">
				<a href="javascript:void(0)" style="text-decoration:none;" class="quiz_load"><?php echo esc_html( $quiz_title ); ?></a>
			</div>
			<div class="qrecolumn_2 columns">
				<?php echo esc_html( $quiz_date ); ?>
			</div>
			<div class="qrecolumn_3 columns">
				<?php echo esc_html( $quiz_percentage ) . '%'; ?>
			</div>
			<div class="qrecolumn_4 columns">
				<?php echo $download_report_link; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</div>
		</div>
		<div class="qre_prev_div" id="qre_quiz_details_<?php echo esc_attr( $count ); ?>"></div>
		<?php
	}
}
$all_ids = array_column( $quiz, 'statistic_ref_id' );
if ( count( $all_ids ) > 1 ) {
	?>
	<a id="qre_export_all" href="#" data-ref_id="<?php echo esc_attr( implode( ',', $all_ids ) ); ?>" class="qre-export qre-export-all button-secondary qre-download-csv" style="margin-right:15px;">
		<?php echo esc_html__( 'Export All in CSV', 'quiz_reporting_learndash' ); ?>
	</a>
	<a id="qre_export_all" href="#" data-ref_id="<?php echo esc_attr( implode( ',', $all_ids ) ); ?>" class="qre-export qre-export-all button-secondary qre-download-xlsx" style="margin-right:3px;">
		<?php echo esc_html__( 'Export All in Excel', 'quiz_reporting_learndash' ); ?>
	</a>
	<?php
}
