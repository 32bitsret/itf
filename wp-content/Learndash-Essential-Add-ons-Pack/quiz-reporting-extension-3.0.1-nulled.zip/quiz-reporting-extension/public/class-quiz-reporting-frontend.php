<?php
/**
 * Report Export data generation.
 *
 * @package Quiz Reporting Extension
 * @since   3.0.0
 */

defined( 'ABSPATH' ) || exit;
if ( ! class_exists( 'Quiz_Reporting_Frontend' ) ) {
	/**
	 * Quiz_Reporting_Frontend Class.
	 *
	 * @class Quiz_Reporting_Frontend
	 */
	class Quiz_Reporting_Frontend {
		/**
		 * The single instance of the class.
		 *
		 * @var Quiz_Reporting_Frontend
		 * @since 2.1
		 */
		protected static $instance = null;

		/**
		 * Quiz_Reporting_Frontend Instance.
		 *
		 * Ensures only one instance of Quiz_Reporting_Frontend is loaded or can be loaded.
		 *
		 * @since 3.0.0
		 * @static
		 * @return Quiz_Reporting_Frontend - instance.
		 */
		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Quiz_Reporting_Frontend Constructor.
		 */
		public function __construct() {
			$this->init_hooks();
		}

		/**
		 * Hook into actions and filters.
		 *
		 * @since 3.0.0
		 */
		private function init_hooks() {
			add_action( 'wp_ajax_qre_live_search', array( $this, 'qre_live_search' ) );
			add_action( 'wp_ajax_qre_save_filters', array( $this, 'qre_save_filters' ) );
			add_action( 'wp_ajax_qre_get_filters', array( $this, 'qre_get_filters' ) );
		}

		/**
		 * This method is used to get statistic reports based on query params.
		 *
		 * @internal Currently Not in Use. Will need it later for Rest API endpoints.
		 */
		public function show_paginated_entries() {
			$query_type     = filter_input( INPUT_GET, 'search_result_type', FILTER_SANITIZE_STRING );
			$queried_obj_id = filter_input( INPUT_GET, 'search_result_id', FILTER_VALIDATE_INT );
			$queried_string = filter_input( INPUT_GET, 'qre-search-field', FILTER_SANITIZE_STRING );
			$date_filter    = filter_input( INPUT_GET, 'filter_type', FILTER_SANITIZE_STRING );
			$time_period    = filter_input( INPUT_GET, 'period', FILTER_SANITIZE_STRING );
			$from_date      = filter_input( INPUT_GET, 'from_date', FILTER_SANITIZE_STRING );
			$to_date        = filter_input( INPUT_GET, 'to_date', FILTER_SANITIZE_STRING );
			$limit          = filter_input( INPUT_GET, 'limit', FILTER_SANITIZE_STRING );
			$page           = filter_input( INPUT_GET, 'pageno', FILTER_SANITIZE_STRING );
			$security       = filter_input( INPUT_GET, 'security', FILTER_SANITIZE_STRING );

			if ( empty( $security ) || ! wp_verify_nonce( $security, 'refresh_page_entries' ) ) {
				$error = new WP_Error( 403, __( 'Illegal Request. Identifying security token is either missing or is incorrect.', 'quiz_reporting_learndash' ) );
				wp_send_json_error( $error );
				die();
			}

			$statistics = Quiz_Export_Data::instance()->get_filtered_statistics( $query_type, $queried_obj_id, $queried_string, $date_filter, $time_period, $from_date, $to_date, $limit, $page );
			if ( is_wp_error( $statistics ) ) {
				wp_send_json_error( $statistics );
				die();
			}
			$statistic_data = array_map(
				function( $statistic ) {
					if ( ! array_key_exists( 'statistic_ref_id', $statistic ) ) {
						return;
					}
					$data                 = Quiz_Export_Db::instance()->get_statistic_summarized_data( $statistic['statistic_ref_id'] );
					$data['quiz_title']   = "<a href='" . add_query_arg(
						array(
							'report'    => 'quiz',
							'screen'    => 'quiz',
							'user'      => $statistic['user_id'],
							'quiz'      => $statistic['quiz_id'],
							'statistic' => $statistic['statistic_ref_id'],
						),
						get_permalink()
					) . "'>" . get_the_title( learndash_get_quiz_id_by_pro_quiz_id( $statistic['quiz_id'] ) ) . '</a>';
					$data['user_name']    = "<a href='" . add_query_arg(
						array(
							'report' => 'quiz',
							'screen' => 'user',
							'user'   => $statistic['user_id'],
						),
						get_permalink()
					) . "'>" . get_userdata( $statistic['user_id'] )->display_name . '</a>';
					$data['date_attempt'] = date_i18n( get_option( 'date_format', 'd-M-Y' ), $statistic['create_time'] );
					/* translators: %1$d: Points Earned, %2$d: Total Points */
					$data['score']      = sprintf( __( '%1$d of %2$d', 'quiz_reporting_learndash' ), $data['points'], $data['gpoints'] );
					$dt_current         = new \DateTime( '@0' );
					$dt_after_seconds   = new \DateTime( '@' . (int) $data['question_time'] );
					$data['time_taken'] = $dt_current->diff( $dt_after_seconds )->format( '%H:%I:%S' );
					$data['link']       = "<a href='#' data-ref_id='" . $statistic['statistic_ref_id'] . "' class=\"qre-export qre-download-csv\"><img src='" . QRE_PLUGIN_URL . 'assets/public/images/csv.svg' . "'/></a>&nbsp;&nbsp;&nbsp;<a href='#' data-ref_id='" . $statistic['statistic_ref_id'] . "' class=\"qre-export qre-download-xlsx\"><img src='" . QRE_PLUGIN_URL . 'assets/public/images/xls.svg' . "'/></a>";
					return $data;
				},
				$statistics
			);
			$statistic_data = remove_empty_array_items( $statistic_data );
			if ( empty( $statistic_data ) ) {
				$error = new WP_Error( 200, __( 'No Data to Display.', 'quiz_reporting_learndash' ) );
				wp_send_json_error( $error );
				die();
			}
			wp_send_json_success( $statistic_data );
			die();
		}

		/**
		 * This method is used to execute the live search feature query and send realtime results.
		 */
		public function qre_live_search() {
			$query = filter_input( INPUT_POST, 'query', FILTER_SANITIZE_STRING );
			$nonce = filter_input( INPUT_POST, 'security', FILTER_SANITIZE_STRING );
			if ( ! wp_verify_nonce( $nonce, 'get_search_suggestions' ) ) {
				$error = new WP_Error( 403, __( 'Security check failed. Please try again later.', 'quiz_reporting_learndash' ) );
				wp_send_json_error( $error );
				die();
			}
			if ( empty( $query ) ) {
				$error = new WP_Error( 400, __( 'Empty Search Query.', 'quiz_reporting_learndash' ) );
				wp_send_json_error( $error );
				die();
			}
			if ( strlen( $query ) < 3 ) {
				/* translators: %s: Search Query. */
				wp_send_json_error( array( 'message' => sprintf( __( 'There is no result for "%s".', 'quiz_reporting_learndash' ), $query ) ) );
				die();
			}
			$results      = array();
			$user_results = array();
			$quiz_results = qre_search_quizzes( $query );
			$user_results = qre_search_users( $query );
			$results      = array_merge( $user_results, $quiz_results );
			if ( empty( $results ) ) {
				/* translators: %s: Search Query. */
				wp_send_json_error( array( 'message' => sprintf( __( 'There is no result for "%s".', 'quiz_reporting_learndash' ), $query ) ) );
				die();
			}
			wp_send_json_success( $results );
			die();
			// $user_results = qre_search_users( $query );
		}

		/**
		 * This method is used to save custom reports filter configuration.
		 */
		public function qre_save_filters() {
			$fields = filter_input( INPUT_POST, 'fields', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY );
			$nonce  = filter_input( INPUT_POST, 'security', FILTER_SANITIZE_STRING );
			if ( ! wp_verify_nonce( $nonce, 'custom_reports_nonce' ) ) {
				$error = new WP_Error( 403, __( 'Security check failed. Please try again later.', 'quiz_reporting_learndash' ) );
				wp_send_json_error( $error );
				die();
			}
			update_user_meta( get_current_user_id(), 'qre_custom_reports_saved_query', $fields );
			wp_send_json_success();
			die();
		}

		/**
		 * This method is used to fetch custom reports results.
		 */
		public function qre_get_filters() {
			$nonce = filter_input( INPUT_GET, 'security', FILTER_SANITIZE_STRING );
			if ( ! wp_verify_nonce( $nonce, 'fetch_custom_reports' ) ) {
				$error = new WP_Error( 403, __( 'Security check failed. Please try again later.', 'quiz_reporting_learndash' ) );
				wp_send_json_error( $error );
				die();
			}
			wp_suspend_cache_addition( true );
			$defaults       = array(
				'category_filter'    => -1,
				'course_filter'      => -1,
				'enrollment_from'    => false,
				'enrollment_to'      => false,
				'completion_from'    => false,
				'completion_to'      => false,
				'course_title'       => 'yes',
				'completion_status'  => 'yes',
				'completion_date'    => false,
				'course_category'    => false,
				'last_activity'      => false,
				'enrollment_date'    => false,
				'course_progress'    => false,
				'group_filter'       => -1,
				'group_name'         => false,
				'user_name'          => 'yes',
				'user_email'         => false,
				'user_first_name'    => false,
				'user_last_name'     => false,
				'quiz_filter'        => -1,
				'quiz_status'        => 'yes',
				'quiz_title'         => 'yes',
				'quiz_category'      => 'yes',
				'quiz_points_total'  => 'yes',
				'quiz_points_earned' => 'yes',
				'quiz_score_percent' => 'yes',
				'date_of_attempt'    => 'yes',
				'time_taken'         => 'yes',
				'question_text'      => 'yes',
				'question_options'   => 'yes',
				'correct_answers'    => 'yes',
				'user_answers'       => 'yes',
				'question_type'      => 'yes',
			);
			$filter_options = get_user_meta( get_current_user_id(), 'qre_custom_reports_saved_query', true );
			$filter_options = wp_parse_args( $filter_options, $defaults );

			$data_fields        = array();
			$filter_fields      = array( 'category_filter', 'course_filter', 'enrollment_from', 'enrollment_to', 'completion_from', 'completion_to', 'group_filter', 'quiz_filter' );
			$filter_fields_data = array();
			foreach ( $filter_options as $option_key => $option_value ) {
				if ( 'yes' === $option_value ) {
					$data_fields[ $option_key ] = $option_value;
				}
				if ( in_array( $option_key, $filter_fields, true ) ) {
					$filter_fields_data[ $option_key ] = $option_value;
				}
			}

			if ( empty( $data_fields ) ) {
				$error = new WP_Error( 400, __( 'No data fields selected.', 'quiz_reporting_learndash' ) );
				wp_send_json_error( $error );
				die();
			}
			$user_managed_courses = qre_get_user_managed_group_courses();
			$current_user         = wp_get_current_user();

			if ( -1 !== (int) $filter_fields_data['quiz_filter'] ) {
				$is_quiz_accessible = qre_check_if_quiz_accessible( $filter_fields_data['quiz_filter'], $current_user, $user_managed_courses );
				if ( ! $is_quiz_accessible || is_wp_error( $is_quiz_accessible ) ) {
					$error = new WP_Error( 403, __( 'Requested resource not accessible.', 'quiz_reporting_learndash' ) );
					wp_send_json_error( $error );
					die();
				}
				$data = $this->get_data_by_quiz_id( $filter_fields_data, $data_fields );
				wp_send_json_success( $data );
				die();
			}
			if ( -1 !== (int) $filter_fields_data['course_filter'] ) {
				if ( ! sfwd_lms_has_access( $filter_fields_data['course_filter'] ) ) {
					$error = new WP_Error( 403, __( 'Requested resource not accessible.', 'quiz_reporting_learndash' ) );
					wp_send_json_error( $error );
					die();
				}
				$quizzes = learndash_course_get_steps_by_type( $filter_fields_data['course_filter'], 'sfwd-quiz' );
				$data    = array();
				if ( ! empty( $quizzes ) ) {
					foreach ( $quizzes as $quiz_id ) {
						$filter_fields_data['quiz_filter'] = $quiz_id;
						$data                              = array_merge( $data, $this->get_data_by_quiz_id( $filter_fields_data, $data_fields ) );
					}
					$filter_fields_data['quiz_filter'] = -1;
				}
				wp_send_json_success( $data );
				die();
			}
			if ( -1 !== (int) $filter_fields_data['group_filter'] ) {
				$user_group_ids = learndash_get_administrators_group_ids( $current_user->ID );
				$user_group_ids = array_map( 'absint', $user_group_ids );
				if ( ! in_array( (int) $filter_fields_data['group_filter'], $user_group_ids, true ) ) {
					$error = new WP_Error( 403, __( 'Requested resource not accessible.', 'quiz_reporting_learndash' ) );
					wp_send_json_error( $error );
					die();
				}
				$group_courses = learndash_group_enrolled_courses( $filter_fields_data['group_filter'] );
				$data          = array();
				foreach ( $group_courses as $course_id ) {
					$quizzes = learndash_course_get_steps_by_type( $course_id, 'sfwd-quiz' );
					if ( empty( $quizzes ) ) {
						continue;
					}
					foreach ( $quizzes as $quiz_id ) {
						$filter_fields_data['quiz_filter'] = $quiz_id;
						$data                              = array_merge( $data, $this->get_data_by_quiz_id( $filter_fields_data, $data_fields ) );
					}
					$filter_fields_data['quiz_filter'] = -1;
				}
				wp_send_json_success( $data );
				die();
			}
			if ( -1 !== (int) $filter_fields_data['category_filter'] ) {
				$courses = get_posts(
					array(
						'post_type'   => 'sfwd-courses',
						'numberposts' => -1,
						'fields'      => 'ids',
						'tax_query'   => array(
							array(
								'taxonomy'         => 'ld_course_category',
								'field'            => 'term_id',
								'terms'            => $filter_fields_data['category_filter'], // Where term_id of Term 1 is "1".
								'include_children' => false,
							),
						),
					)
				);
				$data    = array();
				foreach ( $courses as $course_id ) {
					if ( ! sfwd_lms_has_access( $course_id ) ) {
						continue;
					}
					$quizzes = learndash_course_get_steps_by_type( $course_id, 'sfwd-quiz' );
					if ( empty( $quizzes ) ) {
						continue;
					}
					foreach ( $quizzes as $quiz_id ) {
						$filter_fields_data['quiz_filter'] = $quiz_id;
						$data                              = array_merge( $data, $this->get_data_by_quiz_id( $filter_fields_data, $data_fields ) );
					}
					$filter_fields_data['quiz_filter'] = -1;
				}
				wp_send_json_success( $data );
			}
			$quizzes = get_posts(
				array(
					'post_type'   => 'sfwd-quiz',
					'numberposts' => -1,
					'fields'      => 'ids',
				)
			);
			$data    = array();
			foreach ( $quizzes as $quiz_id ) {
				if ( ! qre_check_if_quiz_accessible( $quiz_id, $current_user, $user_managed_courses ) ) {
					continue;
				}
				$filter_fields_data['quiz_filter'] = $quiz_id;
				$data                              = array_merge( $data, $this->get_data_by_quiz_id( $filter_fields_data, $data_fields ) );
			}
			$filter_fields_data['quiz_filter'] = -1;
			wp_send_json_success( $data );
		}

		/**
		 * This method is used to get Custom Reports Data by Quiz ID.
		 *
		 * @param  array $filter_fields Filtering Fields.
		 * @param  array $data_fields   Data Fields.
		 * @return array/null Custom Reports Data.
		 */
		public function get_data_by_quiz_id( $filter_fields, $data_fields ) {
			$quiz_id   = (int) $filter_fields['quiz_filter'];
			$course_id = learndash_get_course_id( $quiz_id );
			$data      = array();
			if ( -1 !== (int) $filter_fields['course_filter'] ) {
				if ( $course_id !== (int) $filter_fields['course_filter'] ) {
					return $data;
				}
			}
			if ( -1 !== (int) $filter_fields['group_filter'] ) {
				if ( ! learndash_group_has_course( $filter_fields['group_filter'], $course_id ) ) {
					return $data;
				}
			}
			if ( -1 !== (int) $filter_fields['category_filter'] ) {
				if ( ! has_term( $filter_fields['category_filter'], 'ld_course_category', $course_id ) ) {
					return $data;
				}
			}
			// $groups      = learndash_get_course_groups( $course_id );
			$quiz_pro_id    = get_post_meta( $quiz_id, 'quiz_pro_id', true );
			$statistics     = Quiz_Export_Db::instance()->get_all_statistic_ref_ids_by_quiz( $quiz_pro_id );
			$statistic_data = array_filter(
				array_map(
					function( $statistic ) use ( $data_fields, $course_id, $quiz_id, $filter_fields ) {
						if ( ! array_key_exists( 'statistic_ref_id', $statistic ) ) {
							return null;
						}
						$current_user         = wp_get_current_user();
						$user_managed_courses = qre_get_user_managed_group_courses();
						$user_id              = (int) $statistic['user_id'];
						$user_info            = get_userdata( $user_id );
						$is_user_accessible   = qre_check_if_user_accessible( $user_id, $current_user, $user_managed_courses );
						if ( ! $is_user_accessible || is_wp_error( $is_user_accessible ) ) {
							return null;
						}
						$courses_access_from = ld_course_access_from( $course_id, $user_id );
						if ( empty( $courses_access_from ) ) {
							$courses_access_from = learndash_user_group_enrolled_to_course_from( $user_id, $course_id, false );
						}
						if ( ! empty( $filter_fields['enrollment_from'] ) ) {
							$enrollment_after = strtotime( $filter_fields['enrollment_from'] );
							if ( $courses_access_from < $enrollment_after ) {
								return null;
							}
						}
						if ( ! empty( $filter_fields['enrollment_to'] ) ) {
							$enrollment_to = strtotime( $filter_fields['enrollment_to'] );
							if ( $courses_access_from >= $enrollment_to ) {
								return null;
							}
						}
						$course_completion_date = learndash_user_get_course_completed_date( $user_id, $course_id );
						if ( ! empty( $filter_fields['completion_from'] ) ) {
							$completion_after = strtotime( $filter_fields['completion_from'] );
							if ( $course_completion_date < $completion_after ) {
								return null;
							}
						}
						if ( ! empty( $filter_fields['completion_to'] ) ) {
							$completion_to = strtotime( $filter_fields['completion_to'] );
							if ( $course_completion_date >= $completion_to ) {
								return null;
							}
						}
						$data = array();
						if ( array_key_exists( 'course_title', $data_fields ) ) {
							$data['course_title'] = get_the_title( $course_id );
						}
						if ( array_key_exists( 'completion_status', $data_fields ) ) {
							$data['completion_status'] = learndash_course_status( $course_id, $user_id );
						}
						if ( array_key_exists( 'completion_date', $data_fields ) ) {
							if ( 0 === (int) $course_completion_date ) {
								$course_completion_date = '-';
							} else {
								$course_completion_date = date_i18n( get_option( 'date_format' ), $course_completion_date );
							}
							$data['completion_date'] = $course_completion_date;
						}
						if ( array_key_exists( 'course_category', $data_fields ) ) {
							$category                = wp_get_post_terms( $course_id, 'ld_course_category', array( 'fields' => 'names' ) );
							$data['course_category'] = '-';
							if ( ! is_wp_error( $category ) ) {
								$data['course_category'] = implode( ', ', $category );
							}
						}
						if ( array_key_exists( 'enrollment_date', $data_fields ) ) {
							$data['enrollment_date'] = date_i18n( get_option( 'date_format', 'd-M-Y' ), $courses_access_from );
						}
						if ( array_key_exists( 'course_progress', $data_fields ) ) {
							$progress = learndash_course_progress(
								array(
									'course_id' => $course_id,
									'user_id'   => $user_id,
									'array'     => true,
								)
							);
							if ( '' === $progress ) {
								$progress = '-';
							} else {
								$progress = $progress['percentage'] . '%';
							}
							$data['course_progress'] = $progress;
						}
						if ( array_key_exists( 'group_name', $data_fields ) ) {
							$user_group_ids = learndash_get_users_group_ids( $user_id, $bypass_transient );

							$user_group_ids = array_map( 'absint', $user_group_ids );

							$course_group_ids = learndash_get_course_groups( $course_id );

							$course_group_ids = array_map( 'absint', $course_group_ids );

							$course_group_ids   = array_intersect( $course_group_ids, $user_group_ids );
							$data['group_name'] = get_the_title( current( $course_group_ids ) );
						}
						if ( array_key_exists( 'user_name', $data_fields ) ) {
							$data['user_name'] = $user_info->display_name;
						}
						if ( array_key_exists( 'user_email', $data_fields ) ) {
							$data['user_email'] = $user_info->user_email;
						}
						if ( array_key_exists( 'user_first_name', $data_fields ) ) {
							$data['user_first_name'] = $user_info->first_name;
						}
						if ( array_key_exists( 'user_last_name', $data_fields ) ) {
							$data['user_last_name'] = $user_info->last_name;
						}
						if ( array_key_exists( 'quiz_title', $data_fields ) ) {
							$data['quiz_title'] = get_the_title( $quiz_id );
						}
						$quiz_data = array();
						if ( array_key_exists( 'quiz_status', $data_fields ) ) {
							if ( empty( $quiz_data ) ) {
								$nonce     = wp_create_nonce( 'quiz_export-' . get_current_user_id() );
								$quiz_data = Quiz_Export_Data::instance()->qre_export_data_generation( $statistic['statistic_ref_id'], $nonce )['arr_data'];
							}
							$quiz_post_settings = learndash_get_setting( $quiz_id );
							if ( ! is_array( $quiz_post_settings ) ) {
								$quiz_post_settings = array();
							}
							if ( ! isset( $quiz_post_settings['passingpercentage'] ) ) {
								$quiz_post_settings['passingpercentage'] = 0;
							}
							$percentage        = (float) number_format( ( $quiz_data[0]['tot_points_scored'] * 100 ) / $quiz_data[0]['total_points'] );
							$passingpercentage = (float) number_format( $quiz_post_settings['passingpercentage'], 2 );
							$pass              = ( $percentage >= $passingpercentage ) ? __( 'PASS', 'quiz_reporting_learndash' ) : __( 'FAIL', 'quiz_reporting_learndash' );

							$data['quiz_status'] = $pass;
						}
						if ( array_key_exists( 'quiz_category', $data_fields ) ) {
							$data['quiz_category'] = '-';
							if ( taxonomy_exists( 'ld_quiz_category' ) ) {
								$data['quiz_category'] = wp_get_post_terms( $quiz_id, 'ld_quiz_category', array( 'fields' => 'names' ) );
							}
						}
						if ( array_key_exists( 'quiz_points_total', $data_fields ) ) {
							if ( empty( $quiz_data ) ) {
								$nonce     = wp_create_nonce( 'quiz_export-' . get_current_user_id() );
								$quiz_data = Quiz_Export_Data::instance()->qre_export_data_generation( $statistic['statistic_ref_id'], $nonce )['arr_data'];
							}
							$data['quiz_points_total'] = $quiz_data[0]['total_points'];
						}
						if ( array_key_exists( 'quiz_points_earned', $data_fields ) ) {
							if ( empty( $quiz_data ) ) {
								$nonce     = wp_create_nonce( 'quiz_export-' . get_current_user_id() );
								$quiz_data = Quiz_Export_Data::instance()->qre_export_data_generation( (int) $statistic['statistic_ref_id'], $nonce );
							}
							$data['quiz_points_earned'] = $quiz_data[0]['tot_points_scored'];
						}
						if ( array_key_exists( 'quiz_score_percent', $data_fields ) ) {
							if ( empty( $quiz_data ) ) {
								$nonce     = wp_create_nonce( 'quiz_export-' . get_current_user_id() );
								$quiz_data = Quiz_Export_Data::instance()->qre_export_data_generation( $statistic['statistic_ref_id'], $nonce )['arr_data'];
							}
							$data['quiz_score_percent'] = number_format( $data['quiz_points_earned'] / $data['quiz_points_total'] * 100, 2 );
						}
						if ( array_key_exists( 'date_of_attempt', $data_fields ) ) {
							$data['date_of_attempt'] = date_i18n( get_option( 'date_format', 'd-M-Y' ), $statistic['create_time'] );
						}
						if ( array_key_exists( 'time_taken', $data_fields ) ) {
							if ( empty( $quiz_data ) ) {
								$nonce     = wp_create_nonce( 'quiz_export-' . get_current_user_id() );
								$quiz_data = Quiz_Export_Data::instance()->qre_export_data_generation( $statistic['statistic_ref_id'], $nonce )['arr_data'];
							}
							$data['time_taken'] = gmdate( 'H:i:s', $quiz_data[0]['tot_time_taken'] );
						}
						if ( array_key_exists( 'question_text', $data_fields ) ) {
							if ( empty( $quiz_data ) ) {
								$nonce     = wp_create_nonce( 'quiz_export-' . get_current_user_id() );
								$quiz_data = Quiz_Export_Data::instance()->qre_export_data_generation( $statistic['statistic_ref_id'], $nonce )['arr_data'];
							}
							/**
							 * Commented Code.
							 * foreach ( $quiz_data[0]['question_meta'] as $qkey => $qval ) {
								$data['question_text'][ $qval['question_id'] ][] = str_replace( '&#39;', "'", html_entity_decode( $qval['question'] ) );
							}*/
							$data['question_meta'] = $quiz_data[0]['question_meta'];
						}
						if ( array_key_exists( 'question_options', $data_fields ) ) {
							if ( empty( $quiz_data ) ) {
								$nonce     = wp_create_nonce( 'quiz_export-' . get_current_user_id() );
								$quiz_data = Quiz_Export_Data::instance()->qre_export_data_generation( $statistic['statistic_ref_id'], $nonce )['arr_data'];
							}
							/**
							 * Commented Code.
							 * foreach ( $quiz_data[0]['question_meta'] as $qkey => $qval ) {
								$data['question_options'][ $qval['question_id'] ][] = str_replace( '&#39;', "'", html_entity_decode( Export_File_Processing::instance()->append_qstn_str( $qval['answers'] ) ) );
							}*/
							$data['question_meta'] = $quiz_data[0]['question_meta'];
						}
						if ( array_key_exists( 'correct_answers', $data_fields ) ) {
							if ( empty( $quiz_data ) ) {
								$nonce     = wp_create_nonce( 'quiz_export-' . get_current_user_id() );
								$quiz_data = Quiz_Export_Data::instance()->qre_export_data_generation( $statistic['statistic_ref_id'], $nonce )['arr_data'];
							}
							/**
							 * Commented Code.
							 * foreach ( $quiz_data[0]['question_meta'] as $qkey => $qval ) {
								$data['correct_answers'][ $qval['question_id'] ][] = str_replace( '&#39;', "'", html_entity_decode( Export_File_Processing::instance()->append_qstn_str( $qval['correct_answers'] ) ) );
							}*/
							$data['question_meta'] = $quiz_data[0]['question_meta'];
						}
						if ( array_key_exists( 'user_answers', $data_fields ) ) {
							if ( empty( $quiz_data ) ) {
								$nonce     = wp_create_nonce( 'quiz_export-' . get_current_user_id() );
								$quiz_data = Quiz_Export_Data::instance()->qre_export_data_generation( $statistic['statistic_ref_id'], $nonce )['arr_data'];
							}
							/**
							 * Commented Code.
							 * [$question_str description]
								$question_str = '';
								foreach ( $qval['user_response'] as $answer ) {
									// user response.
									if ( '' !== $answer ) {
										$question_str .= str_replace( '&#39;', "'", html_entity_decode( $answer ) );
									}
								}
								$data['user_answers'][ $qval['question_id'] ][] = $question_str;
							}*/
							$data['question_meta'] = $quiz_data[0]['question_meta'];
						}
						if ( array_key_exists( 'question_type', $data_fields ) ) {
							if ( empty( $quiz_data ) ) {
								$nonce     = wp_create_nonce( 'quiz_export-' . get_current_user_id() );
								$quiz_data = Quiz_Export_Data::instance()->qre_export_data_generation( $statistic['statistic_ref_id'], $nonce )['arr_data'];
							}
							/**
							 * Commented Code.
							 * foreach ( $quiz_data[0]['question_meta'] as $qkey => $qval ) {
								$data['question_type'][ $qval['question_id'] ][] = $qval['question_type'];
								}
							 */
							$data['question_meta'] = $quiz_data[0]['question_meta'];
						}
						return $data;
					},
					$statistics
				)
			);
			return $statistic_data;
		}

		/**
		 * To get the statistic_ref_id we used creation_time of the quiz, because in the LearnDash version 2.0.6.3, auto generation of statistic_ref_id facility is not provided.
		 *
		 * @param integer $user_id       User ID.
		 * @param integer $pro_quiz_id   Pro Quiz ID.
		 * @param integer $statistics_id Statistics ID.
		 */
		public function display_attempted_questions( $user_id, $pro_quiz_id, $statistics_id ) {
			if ( ! empty( $statistics_id ) ) {
				$questions     = Quiz_Export_Data::instance()->get_statistics_data( $pro_quiz_id, $user_id, $statistics_id, false );
				$questions_key = array();
				if ( ! empty( $questions ) ) {
					$questions_key = array_keys( $questions );
				}
				if ( ! empty( $questions_key ) ) {
					$counter = 0;
					?>
					<div class="learndash">
						<div class="learndash-wrapper">
							<div class="wpProQuiz_content">
								<?php
								// echo $this->show_result_box( $que_count, $pro_quiz_id, $statistics_id );// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped.
								?>
								<div class="wpProQuiz_quiz">
									<span class="questions_heading"><?php echo esc_html( learndash_get_custom_label( 'questions' ) ); ?></span>
									<?php
									foreach ( $questions_key as $key ) {
										foreach ( $questions[ $key ]['questions'] as $value ) {
											$question_id   = $value['question_id'];
											$question_text = ! empty( $value['questionName'] ) ? $value['questionName'] : Quiz_Export_Data::instance()->get_question_text( $pro_quiz_id, $question_id );
											$cmsg          = Quiz_Export_Data::instance()->get_correct_message( $question_id, $pro_quiz_id );
											echo $this->show_user_answer( $question_text, $value['questionAnswerData'], $value['statistcAnswerData'], $value['answerType'], ++$counter, $value['correct'], $cmsg );// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
										}
									}
									?>
								</div>
							</div>
						</div>
					</div>
					<?php
					$que_count = count( $questions[ $key ]['questions'] );
				}
			} else {
				?>
				<center>
					<?php echo esc_html__( 'Statistics not found', 'quiz_reporting_learndash' ); ?>
				</center>
				<?php
			}
		}

		/**
		 * This function is used to show the the Result section.
		 *
		 * @internal Not in Use currently.
		 * @param  integer $que_count     Question count.
		 * @param  integer $pqid          Pro quiz ID.
		 * @param  integer $statistics_id Statistics Reference ID.
		 */
		public function show_result_box( $que_count, $pqid, $statistics_id ) {
			// Primary Data.
			$qcount  = Quiz_Export_Db::instance()->get_total_questions_count( $statistics_id );
			$qscore  = Quiz_Export_Db::instance()->get_correct_questions_count( $statistics_id );
			$qpoints = Quiz_Export_Db::instance()->get_points_earned( $statistics_id );
			$qids    = Quiz_Export_Db::instance()->get_questions_asked( $statistics_id );
			$qtime   = Quiz_Export_Db::instance()->get_quiz_time_taken( $statistics_id );

			// Derived Data.
			$total_points = Quiz_Export_Db::instance()->get_quiz_total_points( $qids );
			$count        = $qcount[0]->count;
			$score        = $qscore[0]->score;
			$points       = $qpoints[0]->points;
			$per          = round( ( $points / $total_points ) * 100, 2 );
			$seconds      = $qtime[0]->quet;
			$time         = round( $seconds );

			$statistic_controller = new \WpProQuiz_Controller_Statistics();
			$avg_res              = $statistic_controller->getAverageResult( $pqid );
			$avg_per              = round( $avg_res, 2 );

			include QRE()::get_template( 'result-box.php' );

			unset( $que_count );
		}

		/**
		 * This function is used to show the anser to the user in a HTML format
		 *
		 * @param  string  $question_text Question Text.
		 * @param  array   $q_answer_data Question Answer Data.
		 * @param  string  $s_answer_data Answer Data.
		 * @param  string  $answer_type   Answer Type.
		 * @param  integer $question_no   Question ID.
		 * @param  boolean $is_correct    Answer is correct or not.
		 * @param  string  $cmg            Correect Message.
		 */
		public function show_user_answer( $question_text, $q_answer_data, $s_answer_data, $answer_type, $question_no, $is_correct, $cmg = null ) {
			$matrix = array();
			if ( 'matrix_sort_answer' === $answer_type ) {
				foreach ( $q_answer_data as $ans_key => $ans_value ) {
					$matrix[ $ans_key ][] = $ans_key;
					foreach ( $q_answer_data as $ans_key2 => $ans_value2 ) {
						if ( $ans_key !== $ans_key2 ) {
							if ( $ans_value->getAnswer() === $ans_value2->getAnswer() ) {
								$matrix[ $ans_key ][] = $ans_key2;
							} elseif ( $ans_value->getSortString() === $ans_value2->getSortString() ) {
								$matrix[ $ans_key ][] = $ans_key2;
							}
						}
					}
				}
			}
			?>
			<div class="wpProQuiz_question">
				<div class="wpProQuiz_question_text">
					<p><?php echo esc_html( $question_no . '. ' ); ?><?php echo $question_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
				</div>
				<?php
				if ( 'matrix_sort_answer' === $answer_type ) {
					$this->display_matrix_sort_answer( $q_answer_data );
				}
				$this->get_question_list( $question_text, $q_answer_data, $s_answer_data, $answer_type, $question_no, $is_correct, $matrix, $cmg );
				?>
			</div>
			<?php
			if ( 'essay' !== $answer_type ) {
				?>
				<div class="wpProQuiz_response">
					<?php
					if ( $is_correct ) {
						?>
						<div class="wpProQuiz_correct">
							<span>
								<?php esc_html_e( 'Correct', 'quiz_reporting_learndash' ); ?>
							</span>
							<p class="wpProQuiz_AnswerMessage">
								<?php echo do_shortcode( apply_filters( 'comment_text', $cmg, null, null ) ); ?>
							</p>
						</div>
						<?php
					} else {
						?>
						<div class="wpProQuiz_incorrect">
							<span>
								<?php esc_html_e( 'Incorrect', 'quiz_reporting_learndash' ); ?>
							</span>
							<p class="wpProQuiz_AnswerMessage">
								<?php echo do_shortcode( apply_filters( 'comment_text', $cmg, null, null ) ); ?>
							</p>
						</div>
						<?php
					}
					?>
				</div>
				<?php
			}
		}

		/**
		 * Get Matrix sort Answer structure.
		 *
		 * @param  array $q_answer_data Question Answer Data.
		 * @return void
		 */
		public function display_matrix_sort_answer( $q_answer_data ) {
			?>
			<div class="wpProQuiz_matrixSortString">
				<h5 class="wpProQuiz_header">
					<?php esc_html_e( 'Sort elements', 'quiz_reporting_learndash' ); ?>
				</h5>
				<ul class="wpProQuiz_sortStringList">
					<?php
					foreach ( $q_answer_data as $key => $value ) {
						?>
						<li class="wpProQuiz_sortStringItem" data-pos="<?php echo esc_attr( $key ); ?>">
							<?php
								echo $value->isSortStringHtml() ? $value->getSortString() : esc_html( $value->getSortString() );// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							?>
						</li>
						<?php
					}
					?>
				</ul>
				<div style="clear: both;"></div>
			</div>
			<?php
		}

		/**
		 * This function is used to show questions list.
		 *
		 * @param  string  $question_text Question Text.
		 * @param  array   $q_answer_data Question Answer Data.
		 * @param  string  $s_answer_data Answer Data.
		 * @param  string  $answer_type   Answer Type.
		 * @param  integer $question_no   Question ID.
		 * @param  boolean $is_correct    Answer is correct or not.
		 * @param  array   $matrix Matrix type question.
		 * @param  string  $cmg            Correect Message.
		 */
		public function get_question_list( $question_text, $q_answer_data, $s_answer_data, $answer_type, $question_no, $is_correct, $matrix, $cmg = null ) {
			?>
			<ul class="wpProQuiz_questionList">
			<?php
			$max_count = count( $q_answer_data );
			for ( $cnt = 0; $cnt < $max_count; $cnt++ ) {
				$answer_text = $q_answer_data[ $cnt ]->isHtml() ? $q_answer_data[ $cnt ]->getAnswer() : esc_html( $q_answer_data[ $cnt ]->getAnswer() );
				$correct     = '';
				?>
				<?php
				if ( 'single' === $answer_type || 'multiple' === $answer_type ) {
					$this->display_single_multiple_questions( $q_answer_data, $s_answer_data, $answer_text, $answer_type, $cnt );
				} elseif ( 'free_answer' === $answer_type ) {
					$this->display_free_type_answer( $s_answer_data, $q_answer_data, $cnt );
				} elseif ( 'sort_answer' === $answer_type ) {
					$correct   = 'wpProQuiz_answerIncorrect';
					$sort_text = '';

					if ( isset( $s_answer_data[ $cnt ] ) && isset( $q_answer_data[ $s_answer_data[ $cnt ] ] ) ) {
						if ( $s_answer_data[ $cnt ] == $cnt ) {
							$correct = 'wpProQuiz_answerCorrect';
						}
						$ans_val   = $q_answer_data[ $s_answer_data[ $cnt ] ];
						$sort_text = $ans_val->isHtml() ? $ans_val->getAnswer() : esc_html( $ans_val->getAnswer() );
					}
					?>
					<li class="wpProQuiz_questionListItem <?php echo esc_attr( $correct ); ?>" style="margin-left:0px;padding: 3px;">
						<div class="wpProQuiz_sortable qreProQuiz_sortable">
							<?php echo $sort_text;// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</div>
					</li>
					<?php
				} elseif ( 'matrix_sort_answer' === $answer_type ) {
					$correct   = 'wpProQuiz_answerIncorrect';
					$sort_text = '';
					if ( isset( $s_answer_data[ $cnt ] ) && isset( $q_answer_data[ $s_answer_data[ $cnt ] ] ) ) {
						if ( in_array( $s_answer_data[ $cnt ], $matrix[ $cnt ] ) ) {
							$correct = 'wpProQuiz_answerCorrect';
						}
						$ans_val   = $q_answer_data[ $s_answer_data[ $cnt ] ];
						$sort_text = $ans_val->isSortStringHtml() ? $ans_val->getSortString() : esc_html( $ans_val->getSortString() );
					}
					?>
					<li class="wpProQuiz_questionListItem <?php echo esc_attr( $correct ); ?>">
						<table>
							<tbody>
								<tr class="wpProQuiz_mextrixTr">
									<td style = "width:20%">
										<div class="wpProQuiz_maxtrixSortText">
											<?php echo $answer_text;// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
										</div>
									</td>
									<td style = "width:80%">
										<ul class="wpProQuiz_maxtrixSortCriterion">
											<li class="wpProQuiz_sortStringItem" data-pos="0" style="box-shadow: 0px 0px; cursor: auto;">
												<?php echo $sort_text;// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
											</li>
										</ul>
									</td>
								</tr>
							</tbody>
						</table>
					</li>
					<?php
				} elseif ( 'cloze_answer' === $answer_type ) {
					$cloze_data = $this->display_cloze_type_questions( $q_answer_data[ $cnt ]->getAnswer(), $s_answer_data );
					echo $cloze_data['replace']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				} elseif ( 'assessment_answer' === $answer_type ) {
					$assessment_data = $this->display_assessment( $q_answer_data[ $cnt ]->getAnswer(), $s_answer_data );
					echo $assessment_data['replace']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				} elseif ( 'essay' === $answer_type ) {
					$this->display_essay_answer( $s_answer_data );
				}
			}
			?>
			</ul>
			<?php
			unset( $question_text );
			unset( $question_no );
			unset( $is_correct );
			unset( $cmg );
			unset( $matrix );
		}

		/**
		 * This method is used to display single/multiple choice questions.
		 *
		 * @param  array   $q_answer_data Question Answer data.
		 * @param  string  $s_answer_data Answer data.
		 * @param  string  $answer_text   Answer Text.
		 * @param  string  $answer_type   Answer Type.
		 * @param  integer $cnt           Counter.
		 * @return void
		 */
		public function display_single_multiple_questions( $q_answer_data, $s_answer_data, $answer_text, $answer_type, $cnt ) {
			$correct = '';
			if ( $q_answer_data[ $cnt ]->isCorrect() ) {
				$correct = 'wpProQuiz_answerCorrect';
			} elseif ( isset( $s_answer_data[ $cnt ] ) && $s_answer_data[ $cnt ] ) {
				$correct = 'wpProQuiz_answerIncorrect';
			}
			?>
			<li class="wpProQuiz_questionListItem <?php echo esc_attr( $correct ); ?>" style="margin-left:0px;padding: 3px;">
				<label>
					<input disabled="disabled" type="<?php echo 'single' === $answer_type ? 'radio' : 'checkbox'; ?>" <?php echo $s_answer_data[ $cnt ] ? 'checked="checked"' : ''; ?>>
					<?php echo $answer_text;// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</label>
			</li>
			<?php
		}

		/**
		 * This method is used to display free type questions.
		 *
		 * @param  string  $s_answer_data Answer data.
		 * @param  array   $q_answer_data Question Answer data.
		 * @param  integer $cnt           Counter.
		 * @return void
		 */
		public function display_free_type_answer( $s_answer_data, $q_answer_data, $cnt ) {
			$term_ans = str_replace( "\r\n", "\n", strtolower( $q_answer_data[ $cnt ]->getAnswer() ) );
			$term_ans = str_replace( "\r", "\n", $term_ans );
			$term_ans = explode( "\n", $term_ans );
			$term_ans = array_values( array_filter( array_map( 'trim', $term_ans ) ) );
			if ( isset( $s_answer_data[0] ) && in_array( strtolower( trim( $s_answer_data[0] ) ), $term_ans ) ) {
				$correct = 'wpProQuiz_answerCorrect';
			} else {
				$correct = 'wpProQuiz_answerIncorrect';
			}
			?>
			<li class="wpProQuiz_questionListItem <?php echo esc_attr( $correct ); ?>" style="margin-left:0px;padding: 3px;">
				<label>
					<input type="text" disabled="disabled" style="width: 300px; padding: 3px;margin-bottom: 5px;" value="<?php echo esc_attr( $s_answer_data[0] ); ?>">
				</label>
				<br>
			</li>
			<?php
		}

		/**
		 * This method is used to display cloze type questions.
		 *
		 * @param  string $answer_text Answer Text.
		 * @param  array  $answer_data Answer Data.
		 * @return array  $data        Answer Data.
		 */
		public function display_cloze_type_questions( $answer_text, $answer_data ) {
			preg_match_all( '#\{(.*?)(?:\|(\d+))?(?:[\s]+)?\}#im', $answer_text, $matches, PREG_SET_ORDER );
			$data  = array();
			$index = 0;
			foreach ( $matches as $key => $value ) {
				$text            = $value[1];
				$points          = ! empty( $value[2] ) ? (int) $value[2] : 1;
				$row_text        = array();
				$multi_text_data = array();
				$len             = array();
				if ( preg_match_all( '#\[(.*?)\]#im', $text, $multi_text_matches ) ) {
					foreach ( $multi_text_matches[1] as $multi_text ) {
						$str_x             = mb_strtolower( trim( html_entity_decode( $multi_text, ENT_QUOTES ) ) );
						$len[]             = strlen( $str_x );
						$multi_text_data[] = $str_x;
						$row_text[]        = $multi_text;
					}
				} else {
					$str_x             = mb_strtolower( trim( html_entity_decode( $text, ENT_QUOTES ) ) );
					$len[]             = strlen( $str_x );
					$multi_text_data[] = $str_x;
					$row_text[]        = $text;
				}
				$correct           = $this->get_correct_class_name( $answer_data, $index, $row_text );
				$data['data'][]    = $this->get_cloze_answer_html( $correct, $answer_data, $index, $row_text );
				$data['correct'][] = $multi_text_data;
				$data['points'][]  = $points;
				$index++;
			}
			foreach ( $data['data'] as $key => $value ) {
				$answer_text = preg_replace( '/\{[^}]+\}/', $value, $answer_text, 1 );
			}
			$data['replace'] = $answer_text;
			return $data;
		}

		/**
		 * Get Correct/Incorrect class name.
		 *
		 * @param  array   $answer_data Answer Data.
		 * @param  integer $index       Index for numeric array.
		 * @param  array   $row_text    Row Text Array.
		 * @return string  $correct     Class Name.
		 */
		public function get_correct_class_name( $answer_data, $index, $row_text ) {
			$correct = 'wpProQuiz_answerIncorrect';
			if ( isset( $answer_data[ $index ] ) && in_array( $answer_data[ $index ], $row_text ) ) {
				$correct = 'wpProQuiz_answerCorrect';
			}
			return $correct;
		}

		/**
		 * Get Cloze Type Answer HTML.
		 *
		 * @param  string  $correct     Class Name.
		 * @param  array   $answer_data Answer Data.
		 * @param  integer $index       Numeric Index.
		 * @param  array   $row_text    Row Text Array.
		 * @return string  $ans_tag     Answer Tag HTML.
		 */
		public function get_cloze_answer_html( $correct, $answer_data, $index, $row_text ) {
			$ans_tag  = '<span class="wpProQuiz_cloze ' . $correct . '">' . esc_html( isset( $answer_data[ $index ] ) ? empty( $answer_data[ $index ] ) ? '---' : $answer_data[ $index ] : '---' ) . '</span>';
			$ans_tag .= '<span>(' . implode( ', ', $row_text ) . ')</span>';
			return $ans_tag;
		}

		/**
		 * This function is used to fetch the assessment type question data
		 *
		 * @param  string $answer_text Answer Text.
		 * @param  string $answer_data Answer Data.
		 * @return array  $data        Answer Data.
		 */
		public function display_assessment( $answer_text, $answer_data ) {
			preg_match_all( '#\{(.*?)\}#im', $answer_text, $matches );
			$data = array();
			for ( $count = 0, $count_1 = count( $matches[1] ); $count < $count_1; $count++ ) {
				$match = $matches[1][ $count ];
				preg_match_all( '#\[([^\|\]]+)(?:\|(\d+))?\]#im', $match, $qre_ms );
				$ans_html = '';
				$checked  = isset( $answer_data[ $count ] ) ? $answer_data[ $count ] - 1 : -1;
				for ( $count_j = 0, $counterj = count( $qre_ms[1] ); $count_j < $counterj; $count_j++ ) {
					$ans_val   = $qre_ms[1][ $count_j ];
					$ans_html .= '<label><input type="radio" disabled="disabled" ' . ( $checked === $count_j ? 'checked="checked"' : '' ) . '>' . $ans_val . '</label>';
				}
			}
			$data['replace'] = $ans_html;
			return $data;
		}

		/**
		 * This method is used to display essay type questions.
		 *
		 * @param  array $s_answer_data Answer Data.
		 * @return void
		 */
		public function display_essay_answer( $s_answer_data ) {
			if ( ( isset( $s_answer_data['graded_id'] ) ) && ( ! empty( $s_answer_data['graded_id'] ) ) ) {
				$essay_post_status     = get_post_status( $s_answer_data['graded_id'] );
				$essay_post_status_str = '';
				if ( 'graded' === $essay_post_status ) {
					$essay_post_status_str = __( 'Graded', 'quiz_reporting_learndash' );
				} else {
					$essay_post_status_str = __( 'Not Graded', 'quiz_reporting_learndash' );
				}
				?>
				<li class="wpProQuiz_questionListItem">
					<div class="wpProQuiz_sortable">
						<?php
						echo esc_html__( 'Status', 'quiz_reporting_learndash' ) . ' : ' . esc_html( $essay_post_status_str );
						if ( current_user_can( 'edit_post', $s_answer_data['graded_id'] ) ) {
							?>
							(<a target="_blank" href="<?php echo get_post_permalink( $s_answer_data['graded_id'] );// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>"><?php esc_html_e( 'view', 'quiz_reporting_learndash' ); ?></a>)
							<?php
						}
						?>
					</div>
				</li>
				<?php
			}
		}
	}
}
