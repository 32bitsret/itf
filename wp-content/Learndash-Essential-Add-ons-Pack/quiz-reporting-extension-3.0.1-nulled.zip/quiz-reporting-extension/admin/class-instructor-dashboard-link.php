<?php
/**
 * This class is used to add Dashboard links to admin page for creating, viewing and/or repairing the dashboard page.
 *
 * @package Quiz Reporting Extension
 * @since   3.0.0
 */

defined( 'ABSPATH' ) || exit;
if ( ! class_exists( 'Instructor_Dashboard_Link' ) ) {
	/**
	 * Instructor_Dashboard_Link Class.
	 *
	 * @class Instructor_Dashboard_Link
	 */
	class Instructor_Dashboard_Link {
		/**
		 * The single instance of the class.
		 *
		 * @var Instructor_Dashboard_Link
		 * @since 3.0.0
		 */
		protected static $instance = null;

		/**
		 * Instructor_Dashboard_Link Instance.
		 *
		 * Ensures only one instance of Instructor_Dashboard_Link is loaded or can be loaded.
		 *
		 * @since 3.0.0
		 * @static
		 * @return Instructor_Dashboard_Link - instance.
		 */
		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Instructor_Dashboard_Link Constructor.
		 */
		public function __construct() {
			$this->init_hooks();
		}

		/**
		 * Hook into actions and filters.
		 *
		 * @since 3.0.0
		 */
		private function init_hooks() {
			// Action to add submenu page in learndash lms menu.
			// add_action( 'admin_menu', array( $this, 'add_submenu_page_ld' ), 1001 );
			// Action to check required course summary page is present or not.
			add_action( 'admin_init', array( $this, 'check_required_page' ) );
			add_action( 'admin_init', array( $this, 'survey_admin_notice' ) );
		}

		/**
		 * Function to create the admin side settings page of the Quiz Dashboard page.
		 */
		public function add_submenu_page_ld() {
			$quiz_label = learndash_get_custom_label( 'quiz' );
			/* translators: %s: Quiz Custom Label */
			add_submenu_page( 'learndash-lms', sprintf( __( '%s Reporting Dashboard', 'quiz_reporting_learndash' ), $quiz_label ), sprintf( __( '%s Reporting Dashboard', 'quiz_reporting_learndash' ), $quiz_label ), 'manage_options', 'ld_quiz_reporting_dashboard', array( $this, 'quiz_reporting_dashboard_link' ) );
		}

		/**
		 * Callback Function to create the admin side settings page of the Quiz Dashboard page.
		 */
		public function quiz_reporting_dashboard_link() {
			$reporting_dashboard = get_option( 'qre_reporting_dashboard', false );
			if ( ! $reporting_dashboard ) {
				$reporting_dashboard = get_posts(
					array(
						'post_type'   => 'page',
						's'           => 'wdm_quiz_statistics_details',
						'post_status' => 'published',
					)
				);
				if ( ! empty( $reporting_dashboard ) ) {
					$reporting_dashboard = current( $reporting_dashboard )->ID;
				}
			} else {
				$dashboard_post = get_post( $reporting_dashboard );
				if ( empty( $dashboard_post ) || 'publish' !== $dashboard_post->post_status ) {
					$reporting_dashboard = false;
				}
			}
			?>
			<div class="wrap">
				<h1><?php esc_html_e( 'Reporting Dashboard', 'quiz_reporting_learndash' ); ?></h1>
				<form method="post">
					<?php if ( empty( $reporting_dashboard ) ) : ?>
						<?php wp_nonce_field( 'create_nonce', 'create_nonce_field' ); ?>
						<input type="submit" class="button" name="submit" value="<?php echo esc_attr( 'Create Dashboard Page', 'quiz_reporting_learndash' ); ?>">
					<?php else : ?>
						<a class="button" href="<?php echo esc_url( get_permalink( $reporting_dashboard ) ); ?>"><?php echo esc_html__( 'Visit Dashboard', 'quiz_reporting_learndash' ); ?></a>
						<input type="hidden" name="page_id" value="<?php echo esc_attr( $reporting_dashboard ); ?>">
						<?php wp_nonce_field( 'repair_nonce', 'repair_nonce_field' ); ?>
						<input type="submit" class="button" name="submit" value="<?php echo esc_attr( 'Repair Page', 'quiz_reporting_learndash' ); ?>">
					<?php endif; ?>
				</form>
			</div>
			<?php
		}

		/**
		 * Function to create/repair the quiz reporting dashboard page.
		 */
		public function check_required_page() {
			// Only show notices for admins.
			if ( ! current_user_can( 'manage_options' ) ) {
				return;
			}
			$reporting_dashboard = get_posts(
				array(
					'post_type'   => 'page',
					's'           => 'wdm_quiz_statistics_details',
					'post_status' => 'publish',
				)
			);
			$show_repair_notice  = false;
			if ( ! empty( $reporting_dashboard ) ) {
				foreach ( $reporting_dashboard as $dashboard ) {
					if ( has_shortcode( $dashboard->post_content, 'wdm_quiz_statistics_details' ) && 'shortcodes/statistic-details/templates/quiz-reports-dashboard.php' !== get_post_meta( $dashboard->ID, '_wp_page_template', true ) ) {
						$show_repair_notice = true;
					}
				}
			} else {
				add_action( 'admin_notices', array( $this, 'admin_create_notices' ) );
			}
			if ( $show_repair_notice ) {
				add_action( 'admin_notices', array( $this, 'admin_repair_notices' ) );
			}
			$repair_page_nonce = filter_input( INPUT_POST, 'repair_nonce_field', FILTER_SANITIZE_STRING );
			$create_page_nonce = filter_input( INPUT_POST, 'create_nonce_field', FILTER_SANITIZE_STRING );

			if ( ! empty( $create_page_nonce ) && wp_verify_nonce( $create_page_nonce, 'create_nonce' ) ) {
				$quiz_label          = learndash_get_custom_label( 'quiz' );
				$page_args           = array(
					/* translators: %s: Quiz Custom Label. */
					'post_title'   => sprintf( __( '%s Reports', 'quiz_reporting_learndash' ), $quiz_label ),
					'post_content' => '[wdm_quiz_statistics_details]',
					'post_status'  => 'publish',
					'post_type'    => 'page',
				);
				$reporting_dashboard = wp_insert_post( $page_args );
				if ( ! is_wp_error( $reporting_dashboard ) ) {
					update_post_meta( $reporting_dashboard, '_wp_page_template', 'shortcodes/statistic-details/templates/quiz-reports-dashboard.php' );
				}
				wp_safe_redirect( add_query_arg( array( 'qre_create_success' => 1 ) ) );
				exit;
			}
			if ( ! empty( $repair_page_nonce ) && wp_verify_nonce( $repair_page_nonce, 'repair_nonce' ) ) {
				$reporting_dashboard = get_posts(
					array(
						'post_type'   => 'page',
						's'           => 'wdm_quiz_statistics_details',
						'post_status' => 'publish',
					)
				);
				if ( ! empty( $reporting_dashboard ) ) {
					foreach ( $reporting_dashboard as $dashboard ) {
						if ( has_shortcode( $dashboard->post_content, 'wdm_quiz_statistics_details' ) ) {
							update_post_meta( $dashboard->ID, '_wp_page_template', 'shortcodes/statistic-details/templates/quiz-reports-dashboard.php' );
						}
					}
				}
				wp_safe_redirect( add_query_arg( array( 'qre_repair_success' => 1 ) ) );
				exit;
			}
			if ( isset( $_GET['qre_create_success'] ) || ! empty( $_GET['qre_repair_success'] ) ) {
				add_action( 'admin_notices', array( $this, 'show_success_notices' ) );
			}
		}

		/**
		 * To show admin notice if Pages need repairing.
		 *
		 * @since 3.0.0
		 */
		public function admin_repair_notices() {
			$err_inst_msg = sprintf(
				/* translators:  %s: Repair Button HTML */
				__( 'Quiz Reporting Extension pages require repairing. %s', 'quiz_reporting_learndash' ),
				'<form method="POST">' . wp_nonce_field( 'repair_nonce', 'repair_nonce_field' ) . '<input type="submit" class="button" name="submit" value="' . esc_attr__( 'Repair Page(s)', 'quiz_reporting_learndash' ) . '"></form>'
			);
			echo '<div class="error"><p>' . $err_inst_msg . '</p></div>';// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		/**
		 * To show admin notice if Dashboard needs to be created.
		 *
		 * @since 3.0.0
		 */
		public function admin_create_notices() {
			$err_inst_msg = sprintf(
				/* translators:  %s: Repair Button HTML */
				__( 'It seems that a Quiz Reporting page is missing. Do you want to create it? <a href="https://wisdmlabs.com/docs/article/wisdm-quiz-reporting-extension/qre-features/quiz-reports-shortcode/" target="_blank">Know More</a>. %s', 'quiz_reporting_learndash' ),
				'<form method="POST">' . wp_nonce_field( 'create_nonce', 'create_nonce_field' ) . '<input type="submit" class="button" name="submit" value="' . esc_attr__( 'Create Dashboard', 'quiz_reporting_learndash' ) . '"></form>'
			);
			echo '<div class="error"><p>' . $err_inst_msg . '</p></div>';// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		/**
		 * To show admin notice for success.
		 *
		 * @since 3.0.0
		 */
		public function show_success_notices() {
			if ( isset( $_GET['qre_create_success'] ) && ! empty( $_GET['qre_create_success'] ) ) {
				$err_inst_msg = __( 'Quiz Reports page created successfully.', 'quiz_reporting_learndash' );
			} elseif ( isset( $_GET['qre_repair_success'] ) && ! empty( $_GET['qre_repair_success'] ) ) {
				$err_inst_msg = __( 'Quiz Reports page repaired successfully.', 'quiz_reporting_learndash' );
			}
			echo '<div class="notice notice-success"><p>' . $err_inst_msg . '</p></div>';// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		/**
		 * This method is used to add survey notice if notice is not dismissed and dismiss the notice is notice parameter is set.
		 */
		public function survey_admin_notice() {
			if ( isset( $_GET['qre_dismiss_notice'] ) && ! empty( $_GET['qre_dismiss_notice'] ) ) {
				update_option( 'qre_disable_nag', 'yes', false );
			}
			if ( current_user_can( 'manage_options' ) && ! get_option( 'qre_disable_nag', false ) ) {
				add_action( 'admin_notices', array( $this, 'show_survey_notice' ) );
			}
		}

		/**
		 * This method is used to show survey notice.
		 */
		public function show_survey_notice() {
			$is_scheduled = get_option( 'qre_survey_scheduled', false );
			if ( ! $is_scheduled ) {
				update_option( 'qre_survey_scheduled', time() + ( 7 * DAY_IN_SECONDS ) );
				return;
			}
			if ( time() < (int) $is_scheduled ) {
				return;
			}
			$err_inst_msg = sprintf(
				/* translators:  %s: Dismiss Link. */
				__( '<p>Enjoy using Quiz Reporting Extension?</p> <p>Please consider giving your feedback as this will help us improve the product.</p> <a href="https://surveys.hotjar.com/2ff79ea3-f0be-493c-9987-c4684e67de95" target="_blank">Provide your Feedback</a> | <a href="%s">Dismiss</a>', 'quiz_reporting_learndash' ),
				add_query_arg( array( 'qre_dismiss_notice' => 1 ) )
			);
			echo '<div class="notice" style="background-color: #fefece; font-weight: 500;"><p>' . $err_inst_msg . '</p></div>';// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}
}
