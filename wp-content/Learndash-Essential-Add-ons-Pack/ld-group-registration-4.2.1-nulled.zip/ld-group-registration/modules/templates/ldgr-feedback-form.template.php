<?php
/**
 * Feedback Form Template
 *
 * @since 3.2.0
 */
?>
<h2><?php _e('Feedback', 'wdm_ld_group')?></h2>
<!-- <div id="ldgr-feedback-form"> -->
<script>(function(t,e,s,n){var o,a,c;t.SMCX=t.SMCX||[],e.getElementById(n)||(o=e.getElementsByTagName(s),a=o[o.length-1],c=e.createElement(s),c.type="text/javascript",c.async=!0,c.id=n,c.src=["https:"===location.protocol?"https://":"http://","widget.surveymonkey.com/collect/website/js/tRaiETqnLgj758hTBazgd3sVvnzL7B8f6Z6hCWTgfzeQzx84Eo0wgzKddzuF34Vv.js"].join(""),a.parentNode.insertBefore(c,a))})(window,document,"script","smcx-sdk");</script><a style="font: 12px Helvetica, sans-serif; color: #999; text-decoration: none;" href=https://www.surveymonkey.com></a>
<!-- </div> -->
