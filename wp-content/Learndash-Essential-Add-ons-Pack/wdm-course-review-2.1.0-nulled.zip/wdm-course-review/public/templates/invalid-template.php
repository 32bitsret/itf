<?php
/**
 * This file is the invalid ajax call error message.
 *
 * @package RatingsReviewsFeedback\Public\Reviews
 */

?>
<div class="modal">
	<?php esc_html_e( 'Something seems to be wrong!!! Please try again later.', 'wdm_ld_course_review' ); ?>
</div>
