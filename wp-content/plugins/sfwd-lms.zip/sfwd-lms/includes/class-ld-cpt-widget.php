<?php
/**
 * Registers widget for displaying a list of lessons for a course and tracks lesson progress.
 *
 * @since 2.1.0
 *
 * @package LearnDash\CPT
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
