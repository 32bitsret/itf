wp.domReady( function () {
    wp.blocks.unregisterBlockType( 'learndash/ld-exam' );
} );