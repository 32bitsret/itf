<?php
/**
 *  PHP-PayPal-IPN Handler
 *
 * @deprecated 3.6.0 {@see 'includes/payments/class-learndash-paypal-ipn.php'} instead
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

_deprecated_file( basename( __FILE__ ), '3.6.0', 'includes/payments/class-learndash-paypal-ipn.php' );
