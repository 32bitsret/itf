<?php
/**
 * Deprecated functions from past LearnDash versions. You shouldn't use these
 * functions and look for the alternatives instead. The functions will be
 * removed in a later version.
 *
 * @package LearnDash
 * @subpackage Deprecated
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/3.6.0/functions.php';
require_once __DIR__ . '/3.5.1/functions.php';
require_once __DIR__ . '/3.5.0/functions.php';
require_once __DIR__ . '/3.4.1/functions.php';
require_once __DIR__ . '/3.4.0/functions.php';
require_once __DIR__ . '/3.3.0/functions.php';
require_once __DIR__ . '/3.2.3/functions.php';
require_once __DIR__ . '/3.2.0/functions.php';
require_once __DIR__ . '/3.1.7/functions.php';
require_once __DIR__ . '/3.1.2/functions.php';
require_once __DIR__ . '/3.1.0/functions.php';
require_once __DIR__ . '/2.6.4/functions.php';
require_once __DIR__ . '/2.6.0/functions.php';
require_once __DIR__ . '/2.5.0/functions.php';
require_once __DIR__ . '/2.3.0/functions.php';
