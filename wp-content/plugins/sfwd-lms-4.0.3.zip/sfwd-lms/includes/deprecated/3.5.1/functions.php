<?php
/**
 * Deprecated functions from LD 3.5.1
 * The functions will be removed in a later version.
 *
 * @package LearnDash\Deprecated
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Other deprecated class functions.
 */
/**
 * includes/course/ld-course-progress.php apply_filters( 'learndash_quiz_complete_essay_grded' )
 */

