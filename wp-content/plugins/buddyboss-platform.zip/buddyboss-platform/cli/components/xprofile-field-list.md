#	wp bp xprofile field list

Get a list of XProfile fields.

## OPTIONS

[--&lt;field&gt;=&lt;value&gt;]
: One or more parameters to pass. See bp_xprofile_get_groups()

## EXAMPLE

    $ wp bp xprofile field list
