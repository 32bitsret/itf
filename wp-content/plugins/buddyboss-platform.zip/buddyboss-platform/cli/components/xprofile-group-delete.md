#	wp bp xprofile group delete

Delete a specific XProfile field group.

## OPTIONS

&lt;field-group-id&gt;...
: ID or IDs for the field group.

[--yes]
: Answer yes to the confirmation message.

## EXAMPLE

    $ wp bp xprofile group delete 500 --yes
